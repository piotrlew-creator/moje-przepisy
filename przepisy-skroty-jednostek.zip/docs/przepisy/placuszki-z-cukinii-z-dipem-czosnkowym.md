---
hide:
  - toc
---

<a class="p-back" href="../../">&larr; Wszystkie przepisy</a>

# Placuszki z cukinii z dipem czosnkowym

<div class="p-hero" data-slot="3">
<div class="p-hero__top">
<span>Kolacja</span><span class="p-num">18:00-20:00</span>
</div>
<div class="p-macros">
<div class="p-macro"><span class="p-macro__v">460</span><span class="p-macro__l">kcal</span></div>
<div class="p-macro"><span class="p-macro__v">23 g</span><span class="p-macro__l">białko</span></div>
<div class="p-macro"><span class="p-macro__v">41 g</span><span class="p-macro__l">węgl.</span></div>
<div class="p-macro"><span class="p-macro__v">23 g</span><span class="p-macro__l">tłuszcz</span></div>
</div>
<p style="margin:0;font-size:.66rem;color:var(--p-ink-3);font-weight:600">Wartości dla jednej porcji, tak jak w planie diety.</p>
</div>

<div class="p-servings">
<span class="p-eyebrow">Dla ilu osób gotujesz?</span>
<div class="p-stepper">
<button type="button" class="p-stepper__btn" id="srv-minus" aria-label="Mniej osób">&minus;</button>
<span class="p-stepper__value"><span class="p-stepper__num" id="srv-num" aria-live="polite">1</span><span class="p-stepper__word" id="srv-word">osoba</span></span>
<button type="button" class="p-stepper__btn" id="srv-plus" aria-label="Więcej osób">+</button>
</div>
<p class="p-note" id="srv-note" style="margin:0" hidden></p>
</div>

<div class="p-ings__head">
<h2 id="ing-heading" style="margin:0">Składniki na 1 osobę</h2>
<button type="button" class="p-btn p-btn--ghost" id="swap-reset" style="min-height:auto;padding:6px 8px" hidden>Przywróć oryginał</button>
</div>
<ul class="p-ings" id="ing-list">
<li><div class="p-ing__row"><span class="p-ing__q">1 szt.</span><span class="p-ing__n">cukinii</span><span class="p-ing__g">200 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-0">Zamień na</label>
<select class="p-select" id="swap-0" data-ing="0">
<option value="pomidor">Pomidor</option>
<option value="ogorek">Ogórek</option>
<option value="papryka">Papryka</option>
<option value="cukinia" selected>Cukinia · oryginał</option>
<option value="brokul">Brokuł</option>
<option value="marchewka">Marchewka</option>
<option value="marchew">Marchew</option>
<option value="rzodkiewka">Rzodkiewka</option>
<option value="seler-naciowy">Seler naciowy</option>
<option value="dynia">Dynia</option>
<option value="pieczarki">Pieczarki</option>
<option value="kalafior">Kalafior</option>
<option value="baklazan">Bakłażan</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">4 łyżki</span><span class="p-ing__n">mąki z ciecierzycy</span><span class="p-ing__g">48 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 szt.</span><span class="p-ing__n">jajek kurzych</span><span class="p-ing__g">56 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 ząbek</span><span class="p-ing__n">czosnku</span><span class="p-ing__g">6 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">2.5 łyżki</span><span class="p-ing__n">jogurtu naturalnego</span><span class="p-ing__g">50 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 łyżeczka</span><span class="p-ing__n">majonezu</span><span class="p-ing__g">10 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">3 łyżki</span><span class="p-ing__n">soku z cytryny</span><span class="p-ing__g">18 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 łyżeczka</span><span class="p-ing__n">oleju rzepakowego</span><span class="p-ing__g">5 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-7">Zamień na</label>
<select class="p-select" id="swap-7" data-ing="7">
<option value="oliwa">Oliwa z oliwek</option>
<option value="olej-rzepakowy" selected>Olej rzepakowy · oryginał</option>
<option value="olej-kokosowy">Olej kokosowy</option>
<option value="olej-z-awokado">Olej z awokado</option>
</select>
</div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">1 szcz.</span><span class="p-ing__n">soli i pieprzu</span><span class="p-ing__g">0.25 g</span></div>
</li>
</ul>

<div class="p-actions">
<button type="button" class="p-btn p-btn--block" id="open-shopping">&#128722; Lista zakupów</button>
<button type="button" class="p-btn p-btn--primary p-btn--block" id="cook-start">Gotujmy &rarr;</button>
</div>

<h2>Sposób przygotowania</h2>
<ol class="p-steps" id="steps-list">
<li>Cukinię zetrzyj na tarce o grubych oczkach, lekko posól i zostaw, aby puściła wodę.</li>
<li>Gdy cukinia puści wodę, odcedź ją, wyciśnij i przełóż do miski.</li>
<li>Do cukinii dodaj jajko, mąkę, olej, posiekany czosnek, sól, pieprz i dokładnie wymieszaj.</li>
<li>Blaszkę wyłóż papierem do pieczenia i ułóż na niej masę na kształt placuszków.</li>
<li>Placuszki piecz w rozgrzanym do 180 stopni piekarniku przez 20-25 minut, aż będą rumiane.</li>
<li>Do miseczki nałóż majonez, jogurt naturalny, czosnek i sok z cytryny. Całość zmiksuj na gładką masę. Dopraw solą i pieprzem do smaku.</li>
<li>Placuszki podaj z dipem czosnkowym. Smacznego! g błonnika, 1110 mg wapnia, 1060 mg magnezu)</li>
</ol>

<div class="p-cook" id="cook" data-open="0" role="dialog" aria-modal="true" aria-label="Gotowanie: Placuszki z cukinii z dipem czosnkowym">
<div class="p-cook__bar">
<span class="p-cook__title">Placuszki z cukinii z dipem czosnkowym</span>
<button type="button" class="p-iconbtn" id="cook-close" aria-label="Zamknij tryb gotowania">&times;</button>
</div>
<div class="p-progress" id="cook-progress"></div>
<div class="p-cook__body">
<span class="p-cook__step" id="cook-label"></span>
<p class="p-cook__text" id="cook-text"></p>
</div>
<div class="p-cook__nav">
<button type="button" class="p-btn" id="cook-prev">Wstecz</button>
<button type="button" class="p-btn p-btn--primary" id="cook-next">Następny krok</button>
</div></div>
<div class="p-sheet" id="shopping" data-open="0" role="dialog" aria-modal="true" aria-label="Lista zakupów">
<button type="button" class="p-sheet__scrim" id="shopping-scrim" aria-label="Zamknij listę zakupów"></button>
<div class="p-sheet__panel">
<div class="p-sheet__head"><h2>Lista zakupów</h2><button type="button" class="p-iconbtn" id="close-shopping" aria-label="Zamknij">&times;</button></div>
<div class="p-sheet__body" id="shopping-body"></div>
<div class="p-sheet__foot">
<button type="button" class="p-btn" id="reset-shopping">Odznacz wszystko</button>
<button type="button" class="p-btn p-btn--primary" id="pdf-btn">Wygeneruj PDF</button>
</div></div></div>
<div class="p-toast" id="toast" role="status" data-on="0"></div>

<script>window.RECIPE = {"slug": "placuszki-z-cukinii-z-dipem-czosnkowym", "title": "Placuszki z cukinii z dipem czosnkowym", "slotLabel": "Kolacja", "time": "18:00-20:00", "baseServings": 1, "ingredients": [{"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "cukinii", "grams": 200.0, "pantry": false, "tag": "cukinia", "swap": {"group": "warzywa", "self": "cukinia", "nameCase": "M"}}, {"qty": 4.0, "unit": "łyżki", "unitLemma": "łyżka", "name": "mąki z ciecierzycy", "grams": 48.0, "pantry": false, "tag": "maka"}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "jajek kurzych", "grams": 56.0, "pantry": false, "tag": "jajka"}, {"qty": 1.0, "unit": "ząbek", "unitLemma": "ząbek", "name": "czosnku", "grams": 6.0, "pantry": false, "tag": "czosnek"}, {"qty": 2.5, "unit": "łyżki", "unitLemma": "łyżka", "name": "jogurtu naturalnego", "grams": 50.0, "pantry": false, "tag": "jogurt"}, {"qty": 1.0, "unit": "łyżeczka", "unitLemma": "łyżeczka", "name": "majonezu", "grams": 10.0, "pantry": false, "tag": "majonez"}, {"qty": 3.0, "unit": "łyżki", "unitLemma": "łyżka", "name": "soku z cytryny", "grams": 18.0, "pantry": false, "tag": "cytryna"}, {"qty": 1.0, "unit": "łyżeczka", "unitLemma": "łyżeczka", "name": "oleju rzepakowego", "grams": 5.0, "pantry": false, "tag": "oliwa", "swap": {"group": "tluszcz", "self": "olej-rzepakowy", "nameCase": "D"}}, {"qty": 1.0, "unit": "szczypta", "unitLemma": "szczypta", "name": "soli i pieprzu", "grams": 0.25, "pantry": true, "tag": null}], "steps": ["«0|B|||U» zetrzyj na tarce o grubych oczkach, lekko posól i zostaw, aby puściła wodę.", "Gdy «0|M|||» puści wodę, odcedź ją, wyciśnij i przełóż do miski.", "Do «0|D|||» dodaj jajko, mąkę, olej, posiekany czosnek, sól, pieprz i dokładnie wymieszaj.", "Blaszkę wyłóż papierem do pieczenia i ułóż na niej masę na kształt placuszków.", "Placuszki piecz w rozgrzanym do 180 stopni piekarniku przez 20-25 minut, aż będą rumiane.", "Do miseczki nałóż majonez, jogurt naturalny, czosnek i sok z cytryny. Całość zmiksuj na gładką masę. Dopraw solą i pieprzem do smaku.", "Placuszki podaj z dipem czosnkowym. Smacznego! g błonnika, 1110 mg wapnia, 1060 mg magnezu)"]};
window.UNITS = {"łyżka": ["łyżka", "łyżki", "łyżek", "łyżki"], "łyżeczka": ["łyżeczka", "łyżeczki", "łyżeczek", "łyżeczki"], "sztuka": ["sztuka", "sztuki", "sztuk", "sztuki"], "garść": ["garść", "garście", "garści", "garści"], "kromka": ["kromka", "kromki", "kromek", "kromki"], "plaster": ["plaster", "plastry", "plastrów", "plastra"], "szklanka": ["szklanka", "szklanki", "szklanek", "szklanki"], "opakowanie": ["opakowanie", "opakowania", "opakowań", "opakowania"], "ząbek": ["ząbek", "ząbki", "ząbków", "ząbka"], "szczypta": ["szczypta", "szczypty", "szczypt", "szczypty"], "porcja": ["porcja", "porcje", "porcji", "porcji"], "puszka": ["puszka", "puszki", "puszek", "puszki"], "kostka": ["kostka", "kostki", "kostek", "kostki"], "listek": ["listek", "listki", "listków", "listka"], "łodyga": ["łodyga", "łodygi", "łodyg", "łodygi"]};
window.SWAPS = {"tluszcz": {"label": "Oliwa i oleje", "options": [{"id": "oliwa", "label": "Oliwa z oliwek", "rodzaj": "f", "formy": {"M": "oliwa z oliwek", "D": "oliwy z oliwek", "B": "oliwę z oliwek", "N": "oliwą z oliwek", "Ms": "oliwie z oliwek"}, "rodzajB": "f"}, {"id": "olej-rzepakowy", "label": "Olej rzepakowy", "rodzaj": "m", "formy": {"M": "olej rzepakowy", "D": "oleju rzepakowego", "B": "olej rzepakowy", "N": "olejem rzepakowym", "Ms": "oleju rzepakowym"}, "rodzajB": "m"}, {"id": "olej-kokosowy", "label": "Olej kokosowy", "rodzaj": "m", "formy": {"M": "olej kokosowy", "D": "oleju kokosowego", "B": "olej kokosowy", "N": "olejem kokosowym", "Ms": "oleju kokosowym"}, "rodzajB": "m"}, {"id": "olej-z-awokado", "label": "Olej z awokado", "rodzaj": "m", "formy": {"M": "olej z awokado", "D": "oleju z awokado", "B": "olej z awokado", "N": "olejem z awokado", "Ms": "oleju z awokado"}, "rodzajB": "m"}]}, "warzywa": {"label": "Warzywa", "options": [{"id": "pomidor", "label": "Pomidor", "rodzaj": "m", "formy": {"M": "pomidor", "D": "pomidora", "B": "pomidor", "N": "pomidorem", "Ms": "pomidorze", "Bpot": "pomidora", "Mpl": "pomidory", "Dpl": "pomidorów", "Bpl": "pomidory", "Npl": "pomidorami", "Mspl": "pomidorach"}, "rodzajB": "mz"}, {"id": "ogorek", "label": "Ogórek", "rodzaj": "m", "formy": {"M": "ogórek", "D": "ogórka", "B": "ogórek", "N": "ogórkiem", "Ms": "ogórku", "Bpot": "ogórka", "Mpl": "ogórki", "Dpl": "ogórków", "Bpl": "ogórki", "Npl": "ogórkami", "Mspl": "ogórkach"}, "rodzajB": "mz"}, {"id": "papryka", "label": "Papryka", "rodzaj": "f", "formy": {"M": "papryka", "D": "papryki", "B": "paprykę", "N": "papryką", "Ms": "papryce", "Mpl": "papryki", "Dpl": "papryk", "Bpl": "papryki", "Npl": "paprykami", "Mspl": "paprykach"}, "rodzajB": "f"}, {"id": "cukinia", "label": "Cukinia", "rodzaj": "f", "formy": {"M": "cukinia", "D": "cukinii", "B": "cukinię", "N": "cukinią", "Ms": "cukinii", "Mpl": "cukinie", "Dpl": "cukinii", "Bpl": "cukinie", "Npl": "cukiniami", "Mspl": "cukiniach"}, "rodzajB": "f"}, {"id": "brokul", "label": "Brokuł", "rodzaj": "m", "formy": {"M": "brokuł", "D": "brokuła", "B": "brokuł", "N": "brokułem", "Ms": "brokule", "Bpot": "brokuła", "Mpl": "brokuły", "Dpl": "brokułów", "Bpl": "brokuły", "Npl": "brokułami", "Mspl": "brokułach"}, "rodzajB": "mz"}, {"id": "marchewka", "label": "Marchewka", "rodzaj": "f", "formy": {"M": "marchewka", "D": "marchewki", "B": "marchewkę", "N": "marchewką", "Ms": "marchewce", "Mpl": "marchewki", "Dpl": "marchewek", "Bpl": "marchewki", "Npl": "marchewkami", "Mspl": "marchewkach"}, "rodzajB": "f"}, {"id": "marchew", "label": "Marchew", "rodzaj": "f", "formy": {"M": "marchew", "D": "marchwi", "B": "marchew", "N": "marchwią", "Ms": "marchwi", "Mpl": "marchwie", "Dpl": "marchwi", "Bpl": "marchwie", "Npl": "marchwiami", "Mspl": "marchwiach"}, "rodzajB": "f"}, {"id": "rzodkiewka", "label": "Rzodkiewka", "rodzaj": "f", "formy": {"M": "rzodkiewka", "D": "rzodkiewki", "B": "rzodkiewkę", "N": "rzodkiewką", "Ms": "rzodkiewce", "Mpl": "rzodkiewki", "Dpl": "rzodkiewek", "Bpl": "rzodkiewki", "Npl": "rzodkiewkami", "Mspl": "rzodkiewkach"}, "rodzajB": "f"}, {"id": "seler-naciowy", "label": "Seler naciowy", "rodzaj": "m", "formy": {"M": "seler naciowy", "D": "selera naciowego", "B": "seler naciowy", "N": "selerem naciowym", "Ms": "selerze naciowym", "Mpl": "selery naciowe", "Dpl": "selerów naciowych", "Bpl": "selery naciowe", "Npl": "selerami naciowymi", "Mspl": "selerach naciowych"}, "rodzajB": "m"}, {"id": "dynia", "label": "Dynia", "rodzaj": "f", "formy": {"M": "dynia", "D": "dyni", "B": "dynię", "N": "dynią", "Ms": "dyni", "Mpl": "dynie", "Dpl": "dyń", "Bpl": "dynie", "Npl": "dyniami", "Mspl": "dyniach"}, "rodzajB": "f"}, {"id": "pieczarki", "label": "Pieczarki", "rodzaj": "pl", "formy": {"M": "pieczarki", "D": "pieczarek", "B": "pieczarki", "N": "pieczarkami", "Ms": "pieczarkach", "Mpl": "pieczarki", "Dpl": "pieczarek", "Bpl": "pieczarki", "Npl": "pieczarkami", "Mspl": "pieczarkach"}, "rodzajB": "pl"}, {"id": "kalafior", "label": "Kalafior", "rodzaj": "m", "formy": {"M": "kalafior", "D": "kalafiora", "B": "kalafior", "N": "kalafiorem", "Ms": "kalafiorze", "Bpot": "kalafiora", "Mpl": "kalafiory", "Dpl": "kalafiorów", "Bpl": "kalafiory", "Npl": "kalafiorami", "Mspl": "kalafiorach"}, "rodzajB": "mz"}, {"id": "baklazan", "label": "Bakłażan", "rodzaj": "m", "formy": {"M": "bakłażan", "D": "bakłażana", "B": "bakłażan", "N": "bakłażanem", "Ms": "bakłażanie", "Bpot": "bakłażana", "Mpl": "bakłażany", "Dpl": "bakłażanów", "Bpl": "bakłażany", "Npl": "bakłażanami", "Mspl": "bakłażanach"}, "rodzajB": "mz"}]}};
window.SWAP_ADJ = {"umyty_B": {"m": "umyty", "f": "umytą", "n": "umyte", "pl": "umyte", "mz": "umytego"}, "swiezy_B": {"m": "świeży", "f": "świeżą", "n": "świeże", "pl": "świeże", "mz": "świeżego"}, "odsaczony_B": {"m": "odsączony", "f": "odsączoną", "n": "odsączone", "pl": "odsączone", "mz": "odsączonego"}, "pieczony_N": {"m": "pieczonym", "f": "pieczoną", "n": "pieczonym", "pl": "pieczonymi", "mz": "pieczonym"}, "pokrojony_B": {"m": "pokrojony", "f": "pokrojoną", "n": "pokrojone", "pl": "pokrojone", "mz": "pokrojonego"}, "ugotowany_B": {"m": "ugotowany", "f": "ugotowaną", "n": "ugotowane", "pl": "ugotowane", "mz": "ugotowanego"}, "podsmazony_B": {"m": "podsmażony", "f": "podsmażoną", "n": "podsmażone", "pl": "podsmażone", "mz": "podsmażonego"}, "przyprawiony_B": {"m": "przyprawiony", "f": "przyprawioną", "n": "przyprawione", "pl": "przyprawione", "mz": "przyprawionego"}, "prazony_N": {"m": "prażonym", "f": "prażoną", "n": "prażonym", "pl": "prażonymi", "mz": "prażonym"}, "pokrojony_N": {"m": "pokrojonym", "f": "pokrojoną", "n": "pokrojonym", "pl": "pokrojonymi", "mz": "pokrojonym"}, "starty_B": {"m": "starty", "f": "startą", "n": "starte", "pl": "starte", "mz": "startego"}, "ugotowany_N": {"m": "ugotowanym", "f": "ugotowaną", "n": "ugotowanym", "pl": "ugotowanymi", "mz": "ugotowanym"}, "przygotowany_B": {"m": "przygotowany", "f": "przygotowaną", "n": "przygotowane", "pl": "przygotowane", "mz": "przygotowanego"}};</script>

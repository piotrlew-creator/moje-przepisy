---
hide:
  - toc
---

<a class="p-back" href="../../">&larr; Wszystkie przepisy</a>

# Bruschetta z soczewicą, świeżymi ziołami i serem grana padano

<div class="p-hero" data-slot="3">
<div class="p-hero__top">
<span>Kolacja</span><span class="p-num">18:00-20:00</span>
</div>
<div class="p-macros">
<div class="p-macro"><span class="p-macro__v">456</span><span class="p-macro__l">kcal</span></div>
<div class="p-macro"><span class="p-macro__v">23 g</span><span class="p-macro__l">białko</span></div>
<div class="p-macro"><span class="p-macro__v">68 g</span><span class="p-macro__l">węgl.</span></div>
<div class="p-macro"><span class="p-macro__v">12 g</span><span class="p-macro__l">tłuszcz</span></div>
</div>
<p style="margin:0;font-size:.66rem;color:var(--p-ink-3);font-weight:600">Wartości dla jednej porcji, tak jak w planie diety.</p>
</div>

<div class="p-servings">
<span class="p-eyebrow">Dla ilu osób gotujesz?</span>
<div class="p-stepper">
<button type="button" class="p-stepper__btn" id="srv-minus" aria-label="Mniej osób">&minus;</button>
<span class="p-stepper__value"><span class="p-stepper__num" id="srv-num" aria-live="polite">1</span><span class="p-stepper__word" id="srv-word">osoba</span></span>
<button type="button" class="p-stepper__btn" id="srv-plus" aria-label="Więcej osób">+</button>
</div>
<p class="p-note" id="srv-note" style="margin:0" hidden></p>
</div>

<div class="p-ings__head">
<h2 id="ing-heading" style="margin:0">Składniki na 1 osobę</h2>
<button type="button" class="p-btn p-btn--ghost" id="swap-reset" style="min-height:auto;padding:6px 8px" hidden>Przywróć oryginał</button>
</div>
<ul class="p-ings" id="ing-list">
<li><div class="p-ing__row"><span class="p-ing__q">1 szt.</span><span class="p-ing__n">bagietki</span><span class="p-ing__g">140 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">14 łyżek</span><span class="p-ing__n">soczewicy czerwonej</span><span class="p-ing__g">140 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-1">Zamień na</label>
<select class="p-select" id="swap-1" data-ing="1">
<option value="ciecierzyca">Ciecierzyca</option>
<option value="soczewica" selected>Soczewica · oryginał</option>
<option value="fasola">Fasola</option>
<option value="groch">Groch</option>
<option value="soja">Soja</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 szt.</span><span class="p-ing__n">pora</span><span class="p-ing__g">140 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">0.5 szt.</span><span class="p-ing__n">cukinii</span><span class="p-ing__g">100 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-3">Zamień na</label>
<select class="p-select" id="swap-3" data-ing="3">
<option value="pomidor">Pomidor</option>
<option value="ogorek">Ogórek</option>
<option value="papryka">Papryka</option>
<option value="cukinia" selected>Cukinia · oryginał</option>
<option value="brokul">Brokuł</option>
<option value="marchewka">Marchewka</option>
<option value="marchew">Marchew</option>
<option value="rzodkiewka">Rzodkiewka</option>
<option value="seler-naciowy">Seler naciowy</option>
<option value="dynia">Dynia</option>
<option value="pieczarki">Pieczarki</option>
<option value="kalafior">Kalafior</option>
<option value="baklazan">Bakłażan</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 szt.</span><span class="p-ing__n">marchwi</span><span class="p-ing__g">45 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-4">Zamień na</label>
<select class="p-select" id="swap-4" data-ing="4">
<option value="pomidor">Pomidor</option>
<option value="ogorek">Ogórek</option>
<option value="papryka">Papryka</option>
<option value="cukinia">Cukinia</option>
<option value="brokul">Brokuł</option>
<option value="marchewka">Marchewka</option>
<option value="marchew" selected>Marchew · oryginał</option>
<option value="rzodkiewka">Rzodkiewka</option>
<option value="seler-naciowy">Seler naciowy</option>
<option value="dynia">Dynia</option>
<option value="pieczarki">Pieczarki</option>
<option value="kalafior">Kalafior</option>
<option value="baklazan">Bakłażan</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 szt.</span><span class="p-ing__n">cebuli</span><span class="p-ing__g">110 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">2 ząbki</span><span class="p-ing__n">czosnku</span><span class="p-ing__g">12 g</span></div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">1 garść</span><span class="p-ing__n">świeżej bazylii</span><span class="p-ing__g">3 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 porcja</span><span class="p-ing__n">sera grana padano</span><span class="p-ing__g">30 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">4 łyżeczki</span><span class="p-ing__n">oleju rzepakowego</span><span class="p-ing__g">20 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-9">Zamień na</label>
<select class="p-select" id="swap-9" data-ing="9">
<option value="oliwa">Oliwa z oliwek</option>
<option value="olej-rzepakowy" selected>Olej rzepakowy · oryginał</option>
<option value="olej-kokosowy">Olej kokosowy</option>
<option value="olej-z-awokado">Olej z awokado</option>
</select>
</div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">1 łyżka</span><span class="p-ing__n">octu balsamicznego</span><span class="p-ing__g">6 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 op.</span><span class="p-ing__n">pomidorów z puszki</span><span class="p-ing__g">400 g</span></div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">1 szcz.</span><span class="p-ing__n">soli i pieprzu</span><span class="p-ing__g">0.25 g</span></div>
</li>
</ul>

<div class="p-actions">
<button type="button" class="p-btn p-btn--block" id="open-shopping">&#128722; Lista zakupów</button>
<button type="button" class="p-btn p-btn--primary p-btn--block" id="cook-start">Gotujmy &rarr;</button>
</div>

<h2>Sposób przygotowania</h2>
<ol class="p-steps" id="steps-list">
<li>W rondlu rozgrzej olej. Smaż posiekaną cebulę z czosnkiem.</li>
<li>Do zeszklonych warzyw dodaj startą marchewkę, cukinię i posiekany por. Podsmaż przez chwilę.</li>
<li>Dodaj soczewicę. Praż przez około 3 minuty, po czym zalej wodą i gotuj na wolnym ogniu, aż soczewica będzie miękka.</li>
<li>Ugotowaną soczewicę i warzywa zalej pomidorami z puszki. Gotuj, aż pomidory się rozgotują, a sos zgęstnieje. Przypraw solą, pieprzem i dodaj posiekaną, świeżą bazylię.</li>
<li>Bagietkę pokrój na kromki. Kromki skrop olejem i przygotuj grzanki na suchej patelni.</li>
<li>Gotowy sos podaj na grzankach, posyp serem grana padano i polej octem balsamicznym. Smacznego!</li>
</ol>

<div class="p-cook" id="cook" data-open="0" role="dialog" aria-modal="true" aria-label="Gotowanie: Bruschetta z soczewicą, świeżymi ziołami i serem grana padano">
<div class="p-cook__bar">
<span class="p-cook__title">Bruschetta z soczewicą, świeżymi ziołami i serem grana padano</span>
<button type="button" class="p-iconbtn" id="cook-close" aria-label="Zamknij tryb gotowania">&times;</button>
</div>
<div class="p-progress" id="cook-progress"></div>
<div class="p-cook__body">
<span class="p-cook__step" id="cook-label"></span>
<p class="p-cook__text" id="cook-text"></p>
</div>
<div class="p-cook__nav">
<button type="button" class="p-btn" id="cook-prev">Wstecz</button>
<button type="button" class="p-btn p-btn--primary" id="cook-next">Następny krok</button>
</div></div>
<div class="p-sheet" id="shopping" data-open="0" role="dialog" aria-modal="true" aria-label="Lista zakupów">
<button type="button" class="p-sheet__scrim" id="shopping-scrim" aria-label="Zamknij listę zakupów"></button>
<div class="p-sheet__panel">
<div class="p-sheet__head"><h2>Lista zakupów</h2><button type="button" class="p-iconbtn" id="close-shopping" aria-label="Zamknij">&times;</button></div>
<div class="p-sheet__body" id="shopping-body"></div>
<div class="p-sheet__foot">
<button type="button" class="p-btn" id="reset-shopping">Odznacz wszystko</button>
<button type="button" class="p-btn p-btn--primary" id="pdf-btn">Wygeneruj PDF</button>
</div></div></div>
<div class="p-toast" id="toast" role="status" data-on="0"></div>

<script>window.RECIPE = {"slug": "bruschetta-z-soczewica-swiezymi-ziolami-i", "title": "Bruschetta z soczewicą, świeżymi ziołami i serem grana padano", "slotLabel": "Kolacja", "time": "18:00-20:00", "baseServings": 1, "ingredients": [{"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "bagietki", "grams": 140.0, "pantry": false, "tag": "bagietka"}, {"qty": 14.0, "unit": "łyżek", "unitLemma": "łyżka", "name": "soczewicy czerwonej", "grams": 140.0, "pantry": false, "tag": "soczewica", "swap": {"group": "straczkowe", "self": "soczewica", "nameCase": "D"}}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "pora", "grams": 140.0, "pantry": false, "tag": "por"}, {"qty": 0.5, "unit": "sztuki", "unitLemma": "sztuka", "name": "cukinii", "grams": 100.0, "pantry": false, "tag": "cukinia", "swap": {"group": "warzywa", "self": "cukinia", "nameCase": "M"}}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "marchwi", "grams": 45.0, "pantry": false, "tag": "marchewka", "swap": {"group": "warzywa", "self": "marchew", "nameCase": "D"}}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "cebuli", "grams": 110.0, "pantry": false, "tag": "cebula"}, {"qty": 2.0, "unit": "ząbki", "unitLemma": "ząbek", "name": "czosnku", "grams": 12.0, "pantry": false, "tag": "czosnek"}, {"qty": 1.0, "unit": "garść", "unitLemma": "garść", "name": "świeżej bazylii", "grams": 3.0, "pantry": true, "tag": null}, {"qty": 1.0, "unit": "porcja", "unitLemma": "porcja", "name": "sera grana padano", "grams": 30.0, "pantry": false, "tag": "grana-padano"}, {"qty": 4.0, "unit": "łyżeczki", "unitLemma": "łyżeczka", "name": "oleju rzepakowego", "grams": 20.0, "pantry": false, "tag": "oliwa", "swap": {"group": "tluszcz", "self": "olej-rzepakowy", "nameCase": "D"}}, {"qty": 1.0, "unit": "łyżka", "unitLemma": "łyżka", "name": "octu balsamicznego", "grams": 6.0, "pantry": true, "tag": null}, {"qty": 1.0, "unit": "opakowanie", "unitLemma": "opakowanie", "name": "pomidorów z puszki", "grams": 400.0, "pantry": false, "tag": "pomidory-puszka"}, {"qty": 1.0, "unit": "szczypta", "unitLemma": "szczypta", "name": "soli i pieprzu", "grams": 0.25, "pantry": true, "tag": null}], "steps": ["W rondlu rozgrzej olej. Smaż posiekaną cebulę z czosnkiem.", "Do zeszklonych warzyw dodaj startą marchewkę, «3|B|||» i posiekany por. Podsmaż przez chwilę.", "Dodaj «1|B|||». Praż przez około 3 minuty, po czym zalej wodą i gotuj na wolnym ogniu, aż «1|M|||» będzie miękka.", "«1|B|ugotowany_B||U» i warzywa zalej pomidorami z puszki. Gotuj, aż pomidory się rozgotują, a sos zgęstnieje. Przypraw solą, pieprzem i dodaj posiekaną, świeżą bazylię.", "Bagietkę pokrój na kromki. Kromki skrop olejem i przygotuj grzanki na suchej patelni.", "Gotowy sos podaj na grzankach, posyp serem grana padano i polej octem balsamicznym. Smacznego!"]};
window.UNITS = {"łyżka": ["łyżka", "łyżki", "łyżek", "łyżki"], "łyżeczka": ["łyżeczka", "łyżeczki", "łyżeczek", "łyżeczki"], "sztuka": ["sztuka", "sztuki", "sztuk", "sztuki"], "garść": ["garść", "garście", "garści", "garści"], "kromka": ["kromka", "kromki", "kromek", "kromki"], "plaster": ["plaster", "plastry", "plastrów", "plastra"], "szklanka": ["szklanka", "szklanki", "szklanek", "szklanki"], "opakowanie": ["opakowanie", "opakowania", "opakowań", "opakowania"], "ząbek": ["ząbek", "ząbki", "ząbków", "ząbka"], "szczypta": ["szczypta", "szczypty", "szczypt", "szczypty"], "porcja": ["porcja", "porcje", "porcji", "porcji"], "puszka": ["puszka", "puszki", "puszek", "puszki"], "kostka": ["kostka", "kostki", "kostek", "kostki"], "listek": ["listek", "listki", "listków", "listka"], "łodyga": ["łodyga", "łodygi", "łodyg", "łodygi"]};
window.SWAPS = {"straczkowe": {"label": "Nasiona roślin strączkowych", "options": [{"id": "ciecierzyca", "label": "Ciecierzyca", "rodzaj": "f", "formy": {"M": "ciecierzyca", "D": "ciecierzycy", "B": "ciecierzycę", "N": "ciecierzycą", "Ms": "ciecierzycy"}, "rodzajB": "f"}, {"id": "soczewica", "label": "Soczewica", "rodzaj": "f", "formy": {"M": "soczewica", "D": "soczewicy", "B": "soczewicę", "N": "soczewicą", "Ms": "soczewicy"}, "rodzajB": "f"}, {"id": "fasola", "label": "Fasola", "rodzaj": "f", "formy": {"M": "fasola", "D": "fasoli", "B": "fasolę", "N": "fasolą", "Ms": "fasoli"}, "rodzajB": "f"}, {"id": "groch", "label": "Groch", "rodzaj": "m", "formy": {"M": "groch", "D": "grochu", "B": "groch", "N": "grochem", "Ms": "grochu"}, "rodzajB": "m"}, {"id": "soja", "label": "Soja", "rodzaj": "f", "formy": {"M": "soja", "D": "soi", "B": "soję", "N": "soją", "Ms": "soi"}, "rodzajB": "f"}]}, "tluszcz": {"label": "Oliwa i oleje", "options": [{"id": "oliwa", "label": "Oliwa z oliwek", "rodzaj": "f", "formy": {"M": "oliwa z oliwek", "D": "oliwy z oliwek", "B": "oliwę z oliwek", "N": "oliwą z oliwek", "Ms": "oliwie z oliwek"}, "rodzajB": "f"}, {"id": "olej-rzepakowy", "label": "Olej rzepakowy", "rodzaj": "m", "formy": {"M": "olej rzepakowy", "D": "oleju rzepakowego", "B": "olej rzepakowy", "N": "olejem rzepakowym", "Ms": "oleju rzepakowym"}, "rodzajB": "m"}, {"id": "olej-kokosowy", "label": "Olej kokosowy", "rodzaj": "m", "formy": {"M": "olej kokosowy", "D": "oleju kokosowego", "B": "olej kokosowy", "N": "olejem kokosowym", "Ms": "oleju kokosowym"}, "rodzajB": "m"}, {"id": "olej-z-awokado", "label": "Olej z awokado", "rodzaj": "m", "formy": {"M": "olej z awokado", "D": "oleju z awokado", "B": "olej z awokado", "N": "olejem z awokado", "Ms": "oleju z awokado"}, "rodzajB": "m"}]}, "warzywa": {"label": "Warzywa", "options": [{"id": "pomidor", "label": "Pomidor", "rodzaj": "m", "formy": {"M": "pomidor", "D": "pomidora", "B": "pomidor", "N": "pomidorem", "Ms": "pomidorze", "Bpot": "pomidora", "Mpl": "pomidory", "Dpl": "pomidorów", "Bpl": "pomidory", "Npl": "pomidorami", "Mspl": "pomidorach"}, "rodzajB": "mz"}, {"id": "ogorek", "label": "Ogórek", "rodzaj": "m", "formy": {"M": "ogórek", "D": "ogórka", "B": "ogórek", "N": "ogórkiem", "Ms": "ogórku", "Bpot": "ogórka", "Mpl": "ogórki", "Dpl": "ogórków", "Bpl": "ogórki", "Npl": "ogórkami", "Mspl": "ogórkach"}, "rodzajB": "mz"}, {"id": "papryka", "label": "Papryka", "rodzaj": "f", "formy": {"M": "papryka", "D": "papryki", "B": "paprykę", "N": "papryką", "Ms": "papryce", "Mpl": "papryki", "Dpl": "papryk", "Bpl": "papryki", "Npl": "paprykami", "Mspl": "paprykach"}, "rodzajB": "f"}, {"id": "cukinia", "label": "Cukinia", "rodzaj": "f", "formy": {"M": "cukinia", "D": "cukinii", "B": "cukinię", "N": "cukinią", "Ms": "cukinii", "Mpl": "cukinie", "Dpl": "cukinii", "Bpl": "cukinie", "Npl": "cukiniami", "Mspl": "cukiniach"}, "rodzajB": "f"}, {"id": "brokul", "label": "Brokuł", "rodzaj": "m", "formy": {"M": "brokuł", "D": "brokuła", "B": "brokuł", "N": "brokułem", "Ms": "brokule", "Bpot": "brokuła", "Mpl": "brokuły", "Dpl": "brokułów", "Bpl": "brokuły", "Npl": "brokułami", "Mspl": "brokułach"}, "rodzajB": "mz"}, {"id": "marchewka", "label": "Marchewka", "rodzaj": "f", "formy": {"M": "marchewka", "D": "marchewki", "B": "marchewkę", "N": "marchewką", "Ms": "marchewce", "Mpl": "marchewki", "Dpl": "marchewek", "Bpl": "marchewki", "Npl": "marchewkami", "Mspl": "marchewkach"}, "rodzajB": "f"}, {"id": "marchew", "label": "Marchew", "rodzaj": "f", "formy": {"M": "marchew", "D": "marchwi", "B": "marchew", "N": "marchwią", "Ms": "marchwi", "Mpl": "marchwie", "Dpl": "marchwi", "Bpl": "marchwie", "Npl": "marchwiami", "Mspl": "marchwiach"}, "rodzajB": "f"}, {"id": "rzodkiewka", "label": "Rzodkiewka", "rodzaj": "f", "formy": {"M": "rzodkiewka", "D": "rzodkiewki", "B": "rzodkiewkę", "N": "rzodkiewką", "Ms": "rzodkiewce", "Mpl": "rzodkiewki", "Dpl": "rzodkiewek", "Bpl": "rzodkiewki", "Npl": "rzodkiewkami", "Mspl": "rzodkiewkach"}, "rodzajB": "f"}, {"id": "seler-naciowy", "label": "Seler naciowy", "rodzaj": "m", "formy": {"M": "seler naciowy", "D": "selera naciowego", "B": "seler naciowy", "N": "selerem naciowym", "Ms": "selerze naciowym", "Mpl": "selery naciowe", "Dpl": "selerów naciowych", "Bpl": "selery naciowe", "Npl": "selerami naciowymi", "Mspl": "selerach naciowych"}, "rodzajB": "m"}, {"id": "dynia", "label": "Dynia", "rodzaj": "f", "formy": {"M": "dynia", "D": "dyni", "B": "dynię", "N": "dynią", "Ms": "dyni", "Mpl": "dynie", "Dpl": "dyń", "Bpl": "dynie", "Npl": "dyniami", "Mspl": "dyniach"}, "rodzajB": "f"}, {"id": "pieczarki", "label": "Pieczarki", "rodzaj": "pl", "formy": {"M": "pieczarki", "D": "pieczarek", "B": "pieczarki", "N": "pieczarkami", "Ms": "pieczarkach", "Mpl": "pieczarki", "Dpl": "pieczarek", "Bpl": "pieczarki", "Npl": "pieczarkami", "Mspl": "pieczarkach"}, "rodzajB": "pl"}, {"id": "kalafior", "label": "Kalafior", "rodzaj": "m", "formy": {"M": "kalafior", "D": "kalafiora", "B": "kalafior", "N": "kalafiorem", "Ms": "kalafiorze", "Bpot": "kalafiora", "Mpl": "kalafiory", "Dpl": "kalafiorów", "Bpl": "kalafiory", "Npl": "kalafiorami", "Mspl": "kalafiorach"}, "rodzajB": "mz"}, {"id": "baklazan", "label": "Bakłażan", "rodzaj": "m", "formy": {"M": "bakłażan", "D": "bakłażana", "B": "bakłażan", "N": "bakłażanem", "Ms": "bakłażanie", "Bpot": "bakłażana", "Mpl": "bakłażany", "Dpl": "bakłażanów", "Bpl": "bakłażany", "Npl": "bakłażanami", "Mspl": "bakłażanach"}, "rodzajB": "mz"}]}};
window.SWAP_ADJ = {"umyty_B": {"m": "umyty", "f": "umytą", "n": "umyte", "pl": "umyte", "mz": "umytego"}, "swiezy_B": {"m": "świeży", "f": "świeżą", "n": "świeże", "pl": "świeże", "mz": "świeżego"}, "odsaczony_B": {"m": "odsączony", "f": "odsączoną", "n": "odsączone", "pl": "odsączone", "mz": "odsączonego"}, "pieczony_N": {"m": "pieczonym", "f": "pieczoną", "n": "pieczonym", "pl": "pieczonymi", "mz": "pieczonym"}, "pokrojony_B": {"m": "pokrojony", "f": "pokrojoną", "n": "pokrojone", "pl": "pokrojone", "mz": "pokrojonego"}, "ugotowany_B": {"m": "ugotowany", "f": "ugotowaną", "n": "ugotowane", "pl": "ugotowane", "mz": "ugotowanego"}, "podsmazony_B": {"m": "podsmażony", "f": "podsmażoną", "n": "podsmażone", "pl": "podsmażone", "mz": "podsmażonego"}, "przyprawiony_B": {"m": "przyprawiony", "f": "przyprawioną", "n": "przyprawione", "pl": "przyprawione", "mz": "przyprawionego"}, "prazony_N": {"m": "prażonym", "f": "prażoną", "n": "prażonym", "pl": "prażonymi", "mz": "prażonym"}, "pokrojony_N": {"m": "pokrojonym", "f": "pokrojoną", "n": "pokrojonym", "pl": "pokrojonymi", "mz": "pokrojonym"}, "starty_B": {"m": "starty", "f": "startą", "n": "starte", "pl": "starte", "mz": "startego"}, "ugotowany_N": {"m": "ugotowanym", "f": "ugotowaną", "n": "ugotowanym", "pl": "ugotowanymi", "mz": "ugotowanym"}, "przygotowany_B": {"m": "przygotowany", "f": "przygotowaną", "n": "przygotowane", "pl": "przygotowane", "mz": "przygotowanego"}};</script>

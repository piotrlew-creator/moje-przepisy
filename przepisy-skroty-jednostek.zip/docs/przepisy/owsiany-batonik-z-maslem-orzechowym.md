---
hide:
  - toc
---

<a class="p-back" href="../../">&larr; Wszystkie przepisy</a>

# Owsiany batonik z masłem orzechowym

<div class="p-hero" data-slot="1">
<div class="p-hero__top">
<span>Śniadanie</span><span class="p-num">7:00-10:00</span>
</div>
<div class="p-macros">
<div class="p-macro"><span class="p-macro__v">477</span><span class="p-macro__l">kcal</span></div>
<div class="p-macro"><span class="p-macro__v">25 g</span><span class="p-macro__l">białko</span></div>
<div class="p-macro"><span class="p-macro__v">57 g</span><span class="p-macro__l">węgl.</span></div>
<div class="p-macro"><span class="p-macro__v">20 g</span><span class="p-macro__l">tłuszcz</span></div>
</div>
<p style="margin:0;font-size:.66rem;color:var(--p-ink-3);font-weight:600">Wartości dla jednej porcji, tak jak w planie diety.</p>
</div>

<div class="p-servings">
<span class="p-eyebrow">Dla ilu osób gotujesz?</span>
<div class="p-stepper">
<button type="button" class="p-stepper__btn" id="srv-minus" aria-label="Mniej osób">&minus;</button>
<span class="p-stepper__value"><span class="p-stepper__num" id="srv-num" aria-live="polite">1</span><span class="p-stepper__word" id="srv-word">osoba</span></span>
<button type="button" class="p-stepper__btn" id="srv-plus" aria-label="Więcej osób">+</button>
</div>
<p class="p-note" id="srv-note" style="margin:0" hidden></p>
</div>

<div class="p-ings__head">
<h2 id="ing-heading" style="margin:0">Składniki na 1 osobę</h2>
<button type="button" class="p-btn p-btn--ghost" id="swap-reset" style="min-height:auto;padding:6px 8px" hidden>Przywróć oryginał</button>
</div>
<ul class="p-ings" id="ing-list">
<li><div class="p-ing__row"><span class="p-ing__q">6 łyżek</span><span class="p-ing__n">płatków owsianych górskich</span><span class="p-ing__g">60 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-0">Zamień na</label>
<select class="p-select" id="swap-0" data-ing="0">
<option value="platki-owsiane" selected>Płatki owsiane · oryginał</option>
<option value="platki-jaglane">Płatki jaglane</option>
<option value="platki-gryczane">Płatki gryczane</option>
<option value="platki-ryzowe">Płatki ryżowe</option>
<option value="platki-orkiszowe">Płatki orkiszowe</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">2 łyżeczki</span><span class="p-ing__n">masła orzechowego</span><span class="p-ing__g">20 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1.5 łyżki</span><span class="p-ing__n">wegańskiej odżywki białkowej</span><span class="p-ing__g">12 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">3 łyżki</span><span class="p-ing__n">mleka roślinnego</span><span class="p-ing__g">45 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-3">Zamień na</label>
<select class="p-select" id="swap-3" data-ing="3">
<option value="mleko-roslinne" selected>Mleko roślinne · oryginał</option>
<option value="napoj-roslinny">Napój roślinny</option>
<option value="napoj-sojowy">Napój sojowy</option>
<option value="napoj-migdalowy">Napój migdałowy</option>
<option value="napoj-owsiany">Napój owsiany</option>
<option value="mleko-2">Mleko 2%</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">3 łyżeczki</span><span class="p-ing__n">nasion chia</span><span class="p-ing__g">15 g</span></div>
</li>
</ul>

<div class="p-actions">
<button type="button" class="p-btn p-btn--block" id="open-shopping">&#128722; Lista zakupów</button>
<button type="button" class="p-btn p-btn--primary p-btn--block" id="cook-start">Gotujmy &rarr;</button>
</div>

<h2>Sposób przygotowania</h2>
<ol class="p-steps" id="steps-list">
<li>Wszystkie składniki batonika, oprócz mleka mieszaj ze sobą. Następnie dolej mleko stopniowo, aż do uzyskania gęstej konsystencji. Uformuj i przełóż do keksówki lub do innego naczynia o dowolnym kształcie tak, aby po schłodzeniu można było wyciąć batoniki. Odstaw do lodówki na 40 minut.</li>
<li>Po wyjęciu z lodówki pokrój małe batoniki. Smacznego!</li>
</ol>

<div class="p-cook" id="cook" data-open="0" role="dialog" aria-modal="true" aria-label="Gotowanie: Owsiany batonik z masłem orzechowym">
<div class="p-cook__bar">
<span class="p-cook__title">Owsiany batonik z masłem orzechowym</span>
<button type="button" class="p-iconbtn" id="cook-close" aria-label="Zamknij tryb gotowania">&times;</button>
</div>
<div class="p-progress" id="cook-progress"></div>
<div class="p-cook__body">
<span class="p-cook__step" id="cook-label"></span>
<p class="p-cook__text" id="cook-text"></p>
</div>
<div class="p-cook__nav">
<button type="button" class="p-btn" id="cook-prev">Wstecz</button>
<button type="button" class="p-btn p-btn--primary" id="cook-next">Następny krok</button>
</div></div>
<div class="p-sheet" id="shopping" data-open="0" role="dialog" aria-modal="true" aria-label="Lista zakupów">
<button type="button" class="p-sheet__scrim" id="shopping-scrim" aria-label="Zamknij listę zakupów"></button>
<div class="p-sheet__panel">
<div class="p-sheet__head"><h2>Lista zakupów</h2><button type="button" class="p-iconbtn" id="close-shopping" aria-label="Zamknij">&times;</button></div>
<div class="p-sheet__body" id="shopping-body"></div>
<div class="p-sheet__foot">
<button type="button" class="p-btn" id="reset-shopping">Odznacz wszystko</button>
<button type="button" class="p-btn p-btn--primary" id="pdf-btn">Wygeneruj PDF</button>
</div></div></div>
<div class="p-toast" id="toast" role="status" data-on="0"></div>

<script>window.RECIPE = {"slug": "owsiany-batonik-z-maslem-orzechowym", "title": "Owsiany batonik z masłem orzechowym", "slotLabel": "Śniadanie", "time": "7:00-10:00", "baseServings": 1, "ingredients": [{"qty": 6.0, "unit": "łyżek", "unitLemma": "łyżka", "name": "płatków owsianych górskich", "grams": 60.0, "pantry": false, "tag": "platki-owsiane", "swap": {"group": "platki", "self": "platki-owsiane", "nameCase": "D"}}, {"qty": 2.0, "unit": "łyżeczki", "unitLemma": "łyżeczka", "name": "masła orzechowego", "grams": 20.0, "pantry": false, "tag": "maslo-orzechowe"}, {"qty": 1.5, "unit": "łyżki", "unitLemma": "łyżka", "name": "wegańskiej odżywki białkowej", "grams": 12.0, "pantry": false, "tag": "odzywka"}, {"qty": 3.0, "unit": "łyżki", "unitLemma": "łyżka", "name": "mleka roślinnego", "grams": 45.0, "pantry": false, "tag": "mleko", "swap": {"group": "mleko", "self": "mleko-roslinne", "nameCase": "D"}}, {"qty": 3.0, "unit": "łyżeczki", "unitLemma": "łyżeczka", "name": "nasion chia", "grams": 15.0, "pantry": false, "tag": "chia"}], "steps": ["Wszystkie składniki batonika, oprócz mleka mieszaj ze sobą. Następnie dolej mleko stopniowo, aż do uzyskania gęstej konsystencji. Uformuj i przełóż do keksówki lub do innego naczynia o dowolnym kształcie tak, aby po schłodzeniu można było wyciąć batoniki. Odstaw do lodówki na 40 minut.", "Po wyjęciu z lodówki pokrój małe batoniki. Smacznego!"]};
window.UNITS = {"łyżka": ["łyżka", "łyżki", "łyżek", "łyżki"], "łyżeczka": ["łyżeczka", "łyżeczki", "łyżeczek", "łyżeczki"], "sztuka": ["sztuka", "sztuki", "sztuk", "sztuki"], "garść": ["garść", "garście", "garści", "garści"], "kromka": ["kromka", "kromki", "kromek", "kromki"], "plaster": ["plaster", "plastry", "plastrów", "plastra"], "szklanka": ["szklanka", "szklanki", "szklanek", "szklanki"], "opakowanie": ["opakowanie", "opakowania", "opakowań", "opakowania"], "ząbek": ["ząbek", "ząbki", "ząbków", "ząbka"], "szczypta": ["szczypta", "szczypty", "szczypt", "szczypty"], "porcja": ["porcja", "porcje", "porcji", "porcji"], "puszka": ["puszka", "puszki", "puszek", "puszki"], "kostka": ["kostka", "kostki", "kostek", "kostki"], "listek": ["listek", "listki", "listków", "listka"], "łodyga": ["łodyga", "łodygi", "łodyg", "łodygi"]};
window.SWAPS = {"mleko": {"label": "Mleko i napoje roślinne", "options": [{"id": "mleko-roslinne", "label": "Mleko roślinne", "rodzaj": "n", "formy": {"M": "mleko roślinne", "D": "mleka roślinnego", "B": "mleko roślinne", "N": "mlekiem roślinnym", "Ms": "mleku roślinnym"}, "rodzajB": "n"}, {"id": "napoj-roslinny", "label": "Napój roślinny", "rodzaj": "m", "formy": {"M": "napój roślinny", "D": "napoju roślinnego", "B": "napój roślinny", "N": "napojem roślinnym", "Ms": "napoju roślinnym"}, "rodzajB": "m"}, {"id": "napoj-sojowy", "label": "Napój sojowy", "rodzaj": "m", "formy": {"M": "napój sojowy", "D": "napoju sojowego", "B": "napój sojowy", "N": "napojem sojowym", "Ms": "napoju sojowym"}, "rodzajB": "m"}, {"id": "napoj-migdalowy", "label": "Napój migdałowy", "rodzaj": "m", "formy": {"M": "napój migdałowy", "D": "napoju migdałowego", "B": "napój migdałowy", "N": "napojem migdałowym", "Ms": "napoju migdałowym"}, "rodzajB": "m"}, {"id": "napoj-owsiany", "label": "Napój owsiany", "rodzaj": "m", "formy": {"M": "napój owsiany", "D": "napoju owsianego", "B": "napój owsiany", "N": "napojem owsianym", "Ms": "napoju owsianym"}, "rodzajB": "m"}, {"id": "mleko-2", "label": "Mleko 2%", "rodzaj": "n", "formy": {"M": "mleko 2%", "D": "mleka 2%", "B": "mleko 2%", "N": "mlekiem 2%", "Ms": "mleku 2%"}, "rodzajB": "n"}]}, "platki": {"label": "Płatki", "options": [{"id": "platki-owsiane", "label": "Płatki owsiane", "rodzaj": "pl", "formy": {"M": "płatki owsiane", "D": "płatków owsianych", "B": "płatki owsiane", "N": "płatkami owsianymi", "Ms": "płatkach owsianych"}, "rodzajB": "pl"}, {"id": "platki-jaglane", "label": "Płatki jaglane", "rodzaj": "pl", "formy": {"M": "płatki jaglane", "D": "płatków jaglanych", "B": "płatki jaglane", "N": "płatkami jaglanymi", "Ms": "płatkach jaglanych"}, "rodzajB": "pl"}, {"id": "platki-gryczane", "label": "Płatki gryczane", "rodzaj": "pl", "formy": {"M": "płatki gryczane", "D": "płatków gryczanych", "B": "płatki gryczane", "N": "płatkami gryczanymi", "Ms": "płatkach gryczanych"}, "rodzajB": "pl"}, {"id": "platki-ryzowe", "label": "Płatki ryżowe", "rodzaj": "pl", "formy": {"M": "płatki ryżowe", "D": "płatków ryżowych", "B": "płatki ryżowe", "N": "płatkami ryżowymi", "Ms": "płatkach ryżowych"}, "rodzajB": "pl"}, {"id": "platki-orkiszowe", "label": "Płatki orkiszowe", "rodzaj": "pl", "formy": {"M": "płatki orkiszowe", "D": "płatków orkiszowych", "B": "płatki orkiszowe", "N": "płatkami orkiszowymi", "Ms": "płatkach orkiszowych"}, "rodzajB": "pl"}]}};
window.SWAP_ADJ = {"umyty_B": {"m": "umyty", "f": "umytą", "n": "umyte", "pl": "umyte", "mz": "umytego"}, "swiezy_B": {"m": "świeży", "f": "świeżą", "n": "świeże", "pl": "świeże", "mz": "świeżego"}, "odsaczony_B": {"m": "odsączony", "f": "odsączoną", "n": "odsączone", "pl": "odsączone", "mz": "odsączonego"}, "pieczony_N": {"m": "pieczonym", "f": "pieczoną", "n": "pieczonym", "pl": "pieczonymi", "mz": "pieczonym"}, "pokrojony_B": {"m": "pokrojony", "f": "pokrojoną", "n": "pokrojone", "pl": "pokrojone", "mz": "pokrojonego"}, "ugotowany_B": {"m": "ugotowany", "f": "ugotowaną", "n": "ugotowane", "pl": "ugotowane", "mz": "ugotowanego"}, "podsmazony_B": {"m": "podsmażony", "f": "podsmażoną", "n": "podsmażone", "pl": "podsmażone", "mz": "podsmażonego"}, "przyprawiony_B": {"m": "przyprawiony", "f": "przyprawioną", "n": "przyprawione", "pl": "przyprawione", "mz": "przyprawionego"}, "prazony_N": {"m": "prażonym", "f": "prażoną", "n": "prażonym", "pl": "prażonymi", "mz": "prażonym"}, "pokrojony_N": {"m": "pokrojonym", "f": "pokrojoną", "n": "pokrojonym", "pl": "pokrojonymi", "mz": "pokrojonym"}, "starty_B": {"m": "starty", "f": "startą", "n": "starte", "pl": "starte", "mz": "startego"}, "ugotowany_N": {"m": "ugotowanym", "f": "ugotowaną", "n": "ugotowanym", "pl": "ugotowanymi", "mz": "ugotowanym"}, "przygotowany_B": {"m": "przygotowany", "f": "przygotowaną", "n": "przygotowane", "pl": "przygotowane", "mz": "przygotowanego"}};</script>

---
hide:
  - toc
---

<a class="p-back" href="../../">&larr; Wszystkie przepisy</a>

# Zupa krem z ciecierzycy z grzankami

<div class="p-hero" data-slot="2">
<div class="p-hero__top">
<span>Obiad</span><span class="p-num">13:00-16:00</span>
</div>
<div class="p-macros">
<div class="p-macro"><span class="p-macro__v">415</span><span class="p-macro__l">kcal</span></div>
<div class="p-macro"><span class="p-macro__v">19 g</span><span class="p-macro__l">białko</span></div>
<div class="p-macro"><span class="p-macro__v">61 g</span><span class="p-macro__l">węgl.</span></div>
<div class="p-macro"><span class="p-macro__v">13 g</span><span class="p-macro__l">tłuszcz</span></div>
</div>
<p style="margin:0;font-size:.66rem;color:var(--p-ink-3);font-weight:600">Wartości dla jednej porcji, tak jak w planie diety.</p>
</div>

<div class="p-servings">
<span class="p-eyebrow">Dla ilu osób gotujesz?</span>
<div class="p-stepper">
<button type="button" class="p-stepper__btn" id="srv-minus" aria-label="Mniej osób">&minus;</button>
<span class="p-stepper__value"><span class="p-stepper__num" id="srv-num" aria-live="polite">1</span><span class="p-stepper__word" id="srv-word">osoba</span></span>
<button type="button" class="p-stepper__btn" id="srv-plus" aria-label="Więcej osób">+</button>
</div>
<p class="p-note" id="srv-note" style="margin:0" hidden></p>
</div>

<div class="p-ings__head">
<h2 id="ing-heading" style="margin:0">Składniki na 1 osobę</h2>
<button type="button" class="p-btn p-btn--ghost" id="swap-reset" style="min-height:auto;padding:6px 8px" hidden>Przywróć oryginał</button>
</div>
<ul class="p-ings" id="ing-list">
<li><div class="p-ing__row"><span class="p-ing__q">1 sztuka</span><span class="p-ing__n">pietruszki</span><span class="p-ing__g">50 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">0.5 sztuki</span><span class="p-ing__n">selera</span><span class="p-ing__g">100 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">0.5 opakowania</span><span class="p-ing__n">ciecierzycy konserwowej</span><span class="p-ing__g">120 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-2">Zamień na</label>
<select class="p-select" id="swap-2" data-ing="2">
<option value="ciecierzyca" selected>Ciecierzyca · oryginał</option>
<option value="soczewica">Soczewica</option>
<option value="fasola">Fasola</option>
<option value="groch">Groch</option>
<option value="soja">Soja</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 sztuka</span><span class="p-ing__n">małej cebuli</span><span class="p-ing__g">55 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 ząbek</span><span class="p-ing__n">czosnku</span><span class="p-ing__g">6 g</span></div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">1 łyżeczka</span><span class="p-ing__n">kurkumy</span><span class="p-ing__g">2 g</span></div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">1 szczypta</span><span class="p-ing__n">soli i pieprzu</span><span class="p-ing__g">0.25 g</span></div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">0.5 szklanki</span><span class="p-ing__n">bulionu warzywnego ekologicznego</span><span class="p-ing__g">125 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 łyżeczka</span><span class="p-ing__n">oliwy z oliwek</span><span class="p-ing__g">5 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-8">Zamień na</label>
<select class="p-select" id="swap-8" data-ing="8">
<option value="oliwa" selected>Oliwa z oliwek · oryginał</option>
<option value="olej-rzepakowy">Olej rzepakowy</option>
<option value="olej-kokosowy">Olej kokosowy</option>
<option value="olej-z-awokado">Olej z awokado</option>
</select>
</div>
</li>
<li data-pantry="1"><div class="p-ing__row"><span class="p-ing__q">2 łyżeczki</span><span class="p-ing__n">tymianku</span><span class="p-ing__g">6 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 plaster</span><span class="p-ing__n">mozzarelli żółtej</span><span class="p-ing__g">15 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 kromka</span><span class="p-ing__n">chleba żytniego razowego</span><span class="p-ing__g">30 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-11">Zamień na</label>
<select class="p-select" id="swap-11" data-ing="11">
<option value="chleb-zytni-razowy" selected>Chleb żytni razowy · oryginał</option>
<option value="chleb-zytni">Chleb żytni</option>
<option value="chleb-orkiszowy">Chleb orkiszowy</option>
<option value="chleb-pelnoziarnisty">Chleb pełnoziarnisty</option>
<option value="chleb-na-zakwasie">Chleb żytni na zakwasie</option>
<option value="bulka-grahamka">Bułka grahamka</option>
<option value="bulka-owsiana">Bułka owsiana</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 sztuka</span><span class="p-ing__n">marchewki</span><span class="p-ing__g">45 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-12">Zamień na</label>
<select class="p-select" id="swap-12" data-ing="12">
<option value="pomidor">Pomidor</option>
<option value="ogorek">Ogórek</option>
<option value="papryka">Papryka</option>
<option value="cukinia">Cukinia</option>
<option value="brokul">Brokuł</option>
<option value="marchewka" selected>Marchewka · oryginał</option>
<option value="marchew">Marchew</option>
<option value="rzodkiewka">Rzodkiewka</option>
<option value="seler-naciowy">Seler naciowy</option>
<option value="dynia">Dynia</option>
<option value="pieczarki">Pieczarki</option>
<option value="kalafior">Kalafior</option>
<option value="baklazan">Bakłażan</option>
</select>
</div>
</li>
</ul>

<div class="p-actions">
<button type="button" class="p-btn p-btn--block" id="open-shopping">&#128722; Lista zakupów</button>
<button type="button" class="p-btn p-btn--primary p-btn--block" id="cook-start">Gotujmy &rarr;</button>
</div>

<h2>Sposób przygotowania</h2>
<ol class="p-steps" id="steps-list">
<li>Piekarnik nagrzej do 200 stopni w trybie termoobieg</li>
<li>Warzywa pokrój na mniejsze kawałki, ciecierzycę odsącz. Razem ułóż na blaszce wyłożonej papierem do pieczenia i polej oliwą, posyp solą, pieprzem, kurkumą oraz tymiankiem.</li>
<li>Warzywa piecz przez 20 minut.</li>
<li>Przełóż warzywa do blendera, wlej bulion, dodaj mozzarellę i zmiksuj na gładki krem. Spróbuj i ewentualnie dopraw solą i pieprzem.</li>
<li>Na suchej patelni podpiecz chleb pokrojony w kostkę, aż stanie się chrupiący. Zupę podaj z grzankami. Smacznego!</li>
</ol>

<div class="p-cook" id="cook" data-open="0" role="dialog" aria-modal="true" aria-label="Gotowanie: Zupa krem z ciecierzycy z grzankami">
<div class="p-cook__bar">
<span class="p-cook__title">Zupa krem z ciecierzycy z grzankami</span>
<button type="button" class="p-iconbtn" id="cook-close" aria-label="Zamknij tryb gotowania">&times;</button>
</div>
<div class="p-progress" id="cook-progress"></div>
<div class="p-cook__body">
<span class="p-cook__step" id="cook-label"></span>
<p class="p-cook__text" id="cook-text"></p>
</div>
<div class="p-cook__nav">
<button type="button" class="p-btn" id="cook-prev">Wstecz</button>
<button type="button" class="p-btn p-btn--primary" id="cook-next">Następny krok</button>
</div></div>
<div class="p-sheet" id="shopping" data-open="0" role="dialog" aria-modal="true" aria-label="Lista zakupów">
<button type="button" class="p-sheet__scrim" id="shopping-scrim" aria-label="Zamknij listę zakupów"></button>
<div class="p-sheet__panel">
<div class="p-sheet__head"><h2>Lista zakupów</h2><button type="button" class="p-iconbtn" id="close-shopping" aria-label="Zamknij">&times;</button></div>
<div class="p-sheet__body" id="shopping-body"></div>
<div class="p-sheet__foot">
<button type="button" class="p-btn" id="reset-shopping">Odznacz wszystko</button>
<button type="button" class="p-btn p-btn--primary" id="pdf-btn">Wygeneruj PDF</button>
</div></div></div>
<div class="p-toast" id="toast" role="status" data-on="0"></div>

<script>window.RECIPE = {"slug": "zupa-krem-z-ciecierzycy-z-grzankami", "title": "Zupa krem z ciecierzycy z grzankami", "slotLabel": "Obiad", "time": "13:00-16:00", "baseServings": 1, "ingredients": [{"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "pietruszki", "grams": 50.0, "pantry": false, "tag": "pietruszka-korzen"}, {"qty": 0.5, "unit": "sztuki", "unitLemma": "sztuka", "name": "selera", "grams": 100.0, "pantry": false, "tag": "seler"}, {"qty": 0.5, "unit": "opakowania", "unitLemma": "opakowanie", "name": "ciecierzycy konserwowej", "grams": 120.0, "pantry": false, "tag": "ciecierzyca", "swap": {"group": "straczkowe", "self": "ciecierzyca", "nameCase": "D"}}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "małej cebuli", "grams": 55.0, "pantry": false, "tag": "cebula"}, {"qty": 1.0, "unit": "ząbek", "unitLemma": "ząbek", "name": "czosnku", "grams": 6.0, "pantry": false, "tag": "czosnek"}, {"qty": 1.0, "unit": "łyżeczka", "unitLemma": "łyżeczka", "name": "kurkumy", "grams": 2.0, "pantry": true, "tag": null}, {"qty": 1.0, "unit": "szczypta", "unitLemma": "szczypta", "name": "soli i pieprzu", "grams": 0.25, "pantry": true, "tag": null}, {"qty": 0.5, "unit": "szklanki", "unitLemma": "szklanka", "name": "bulionu warzywnego ekologicznego", "grams": 125.0, "pantry": true, "tag": null}, {"qty": 1.0, "unit": "łyżeczka", "unitLemma": "łyżeczka", "name": "oliwy z oliwek", "grams": 5.0, "pantry": false, "tag": "oliwa", "swap": {"group": "tluszcz", "self": "oliwa", "nameCase": "D"}}, {"qty": 2.0, "unit": "łyżeczki", "unitLemma": "łyżeczka", "name": "tymianku", "grams": 6.0, "pantry": true, "tag": null}, {"qty": 1.0, "unit": "plaster", "unitLemma": "plaster", "name": "mozzarelli żółtej", "grams": 15.0, "pantry": false, "tag": "mozzarella"}, {"qty": 1.0, "unit": "kromka", "unitLemma": "kromka", "name": "chleba żytniego razowego", "grams": 30.0, "pantry": false, "tag": "chleb", "swap": {"group": "pieczywo", "self": "chleb-zytni-razowy", "nameCase": "D"}}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "marchewki", "grams": 45.0, "pantry": false, "tag": "marchewka", "swap": {"group": "warzywa", "self": "marchewka", "nameCase": "D"}}], "steps": ["Piekarnik nagrzej do 200 stopni w trybie termoobieg", "Warzywa pokrój na mniejsze kawałki, «2|B|||» odsącz. Razem ułóż na blaszce wyłożonej papierem do pieczenia i polej oliwą, posyp solą, pieprzem, kurkumą oraz tymiankiem.", "Warzywa piecz przez 20 minut.", "Przełóż warzywa do blendera, wlej bulion, dodaj mozzarellę i zmiksuj na gładki krem. Spróbuj i ewentualnie dopraw solą i pieprzem.", "Na suchej patelni podpiecz chleb pokrojony w kostkę, aż stanie się chrupiący. Zupę podaj z grzankami. Smacznego!"]};
window.UNITS = {"łyżka": ["łyżka", "łyżki", "łyżek", "łyżki"], "łyżeczka": ["łyżeczka", "łyżeczki", "łyżeczek", "łyżeczki"], "sztuka": ["sztuka", "sztuki", "sztuk", "sztuki"], "garść": ["garść", "garście", "garści", "garści"], "kromka": ["kromka", "kromki", "kromek", "kromki"], "plaster": ["plaster", "plastry", "plastrów", "plastra"], "szklanka": ["szklanka", "szklanki", "szklanek", "szklanki"], "opakowanie": ["opakowanie", "opakowania", "opakowań", "opakowania"], "ząbek": ["ząbek", "ząbki", "ząbków", "ząbka"], "szczypta": ["szczypta", "szczypty", "szczypt", "szczypty"], "porcja": ["porcja", "porcje", "porcji", "porcji"], "puszka": ["puszka", "puszki", "puszek", "puszki"], "kostka": ["kostka", "kostki", "kostek", "kostki"], "listek": ["listek", "listki", "listków", "listka"], "łodyga": ["łodyga", "łodygi", "łodyg", "łodygi"]};
window.SWAPS = {"pieczywo": {"label": "Pieczywo", "options": [{"id": "chleb-zytni-razowy", "label": "Chleb żytni razowy", "rodzaj": "m", "formy": {"M": "chleb żytni razowy", "D": "chleba żytniego razowego", "B": "chleb żytni razowy", "N": "chlebem żytnim razowym", "Ms": "chlebie żytnim razowym"}, "rodzajB": "m"}, {"id": "chleb-zytni", "label": "Chleb żytni", "rodzaj": "m", "formy": {"M": "chleb żytni", "D": "chleba żytniego", "B": "chleb żytni", "N": "chlebem żytnim", "Ms": "chlebie żytnim"}, "rodzajB": "m"}, {"id": "chleb-orkiszowy", "label": "Chleb orkiszowy", "rodzaj": "m", "formy": {"M": "chleb orkiszowy", "D": "chleba orkiszowego", "B": "chleb orkiszowy", "N": "chlebem orkiszowym", "Ms": "chlebie orkiszowym"}, "rodzajB": "m"}, {"id": "chleb-pelnoziarnisty", "label": "Chleb pełnoziarnisty", "rodzaj": "m", "formy": {"M": "chleb pełnoziarnisty", "D": "chleba pełnoziarnistego", "B": "chleb pełnoziarnisty", "N": "chlebem pełnoziarnistym", "Ms": "chlebie pełnoziarnistym"}, "rodzajB": "m"}, {"id": "chleb-na-zakwasie", "label": "Chleb żytni na zakwasie", "rodzaj": "m", "formy": {"M": "chleb żytni na zakwasie", "D": "chleba żytniego na zakwasie", "B": "chleb żytni na zakwasie", "N": "chlebem żytnim na zakwasie", "Ms": "chlebie żytnim na zakwasie"}, "rodzajB": "m"}, {"id": "bulka-grahamka", "label": "Bułka grahamka", "rodzaj": "f", "formy": {"M": "bułka grahamka", "D": "bułki grahamki", "B": "bułkę grahamkę", "N": "bułką grahamką", "Ms": "bułce grahamce"}, "rodzajB": "f"}, {"id": "bulka-owsiana", "label": "Bułka owsiana", "rodzaj": "f", "formy": {"M": "bułka owsiana", "D": "bułki owsianej", "B": "bułkę owsianą", "N": "bułką owsianą", "Ms": "bułce owsianej"}, "rodzajB": "f"}]}, "straczkowe": {"label": "Nasiona roślin strączkowych", "options": [{"id": "ciecierzyca", "label": "Ciecierzyca", "rodzaj": "f", "formy": {"M": "ciecierzyca", "D": "ciecierzycy", "B": "ciecierzycę", "N": "ciecierzycą", "Ms": "ciecierzycy"}, "rodzajB": "f"}, {"id": "soczewica", "label": "Soczewica", "rodzaj": "f", "formy": {"M": "soczewica", "D": "soczewicy", "B": "soczewicę", "N": "soczewicą", "Ms": "soczewicy"}, "rodzajB": "f"}, {"id": "fasola", "label": "Fasola", "rodzaj": "f", "formy": {"M": "fasola", "D": "fasoli", "B": "fasolę", "N": "fasolą", "Ms": "fasoli"}, "rodzajB": "f"}, {"id": "groch", "label": "Groch", "rodzaj": "m", "formy": {"M": "groch", "D": "grochu", "B": "groch", "N": "grochem", "Ms": "grochu"}, "rodzajB": "m"}, {"id": "soja", "label": "Soja", "rodzaj": "f", "formy": {"M": "soja", "D": "soi", "B": "soję", "N": "soją", "Ms": "soi"}, "rodzajB": "f"}]}, "tluszcz": {"label": "Oliwa i oleje", "options": [{"id": "oliwa", "label": "Oliwa z oliwek", "rodzaj": "f", "formy": {"M": "oliwa z oliwek", "D": "oliwy z oliwek", "B": "oliwę z oliwek", "N": "oliwą z oliwek", "Ms": "oliwie z oliwek"}, "rodzajB": "f"}, {"id": "olej-rzepakowy", "label": "Olej rzepakowy", "rodzaj": "m", "formy": {"M": "olej rzepakowy", "D": "oleju rzepakowego", "B": "olej rzepakowy", "N": "olejem rzepakowym", "Ms": "oleju rzepakowym"}, "rodzajB": "m"}, {"id": "olej-kokosowy", "label": "Olej kokosowy", "rodzaj": "m", "formy": {"M": "olej kokosowy", "D": "oleju kokosowego", "B": "olej kokosowy", "N": "olejem kokosowym", "Ms": "oleju kokosowym"}, "rodzajB": "m"}, {"id": "olej-z-awokado", "label": "Olej z awokado", "rodzaj": "m", "formy": {"M": "olej z awokado", "D": "oleju z awokado", "B": "olej z awokado", "N": "olejem z awokado", "Ms": "oleju z awokado"}, "rodzajB": "m"}]}, "warzywa": {"label": "Warzywa", "options": [{"id": "pomidor", "label": "Pomidor", "rodzaj": "m", "formy": {"M": "pomidor", "D": "pomidora", "B": "pomidor", "N": "pomidorem", "Ms": "pomidorze", "Bpot": "pomidora", "Mpl": "pomidory", "Dpl": "pomidorów", "Bpl": "pomidory", "Npl": "pomidorami", "Mspl": "pomidorach"}, "rodzajB": "mz"}, {"id": "ogorek", "label": "Ogórek", "rodzaj": "m", "formy": {"M": "ogórek", "D": "ogórka", "B": "ogórek", "N": "ogórkiem", "Ms": "ogórku", "Bpot": "ogórka", "Mpl": "ogórki", "Dpl": "ogórków", "Bpl": "ogórki", "Npl": "ogórkami", "Mspl": "ogórkach"}, "rodzajB": "mz"}, {"id": "papryka", "label": "Papryka", "rodzaj": "f", "formy": {"M": "papryka", "D": "papryki", "B": "paprykę", "N": "papryką", "Ms": "papryce", "Mpl": "papryki", "Dpl": "papryk", "Bpl": "papryki", "Npl": "paprykami", "Mspl": "paprykach"}, "rodzajB": "f"}, {"id": "cukinia", "label": "Cukinia", "rodzaj": "f", "formy": {"M": "cukinia", "D": "cukinii", "B": "cukinię", "N": "cukinią", "Ms": "cukinii", "Mpl": "cukinie", "Dpl": "cukinii", "Bpl": "cukinie", "Npl": "cukiniami", "Mspl": "cukiniach"}, "rodzajB": "f"}, {"id": "brokul", "label": "Brokuł", "rodzaj": "m", "formy": {"M": "brokuł", "D": "brokuła", "B": "brokuł", "N": "brokułem", "Ms": "brokule", "Bpot": "brokuła", "Mpl": "brokuły", "Dpl": "brokułów", "Bpl": "brokuły", "Npl": "brokułami", "Mspl": "brokułach"}, "rodzajB": "mz"}, {"id": "marchewka", "label": "Marchewka", "rodzaj": "f", "formy": {"M": "marchewka", "D": "marchewki", "B": "marchewkę", "N": "marchewką", "Ms": "marchewce", "Mpl": "marchewki", "Dpl": "marchewek", "Bpl": "marchewki", "Npl": "marchewkami", "Mspl": "marchewkach"}, "rodzajB": "f"}, {"id": "marchew", "label": "Marchew", "rodzaj": "f", "formy": {"M": "marchew", "D": "marchwi", "B": "marchew", "N": "marchwią", "Ms": "marchwi", "Mpl": "marchwie", "Dpl": "marchwi", "Bpl": "marchwie", "Npl": "marchwiami", "Mspl": "marchwiach"}, "rodzajB": "f"}, {"id": "rzodkiewka", "label": "Rzodkiewka", "rodzaj": "f", "formy": {"M": "rzodkiewka", "D": "rzodkiewki", "B": "rzodkiewkę", "N": "rzodkiewką", "Ms": "rzodkiewce", "Mpl": "rzodkiewki", "Dpl": "rzodkiewek", "Bpl": "rzodkiewki", "Npl": "rzodkiewkami", "Mspl": "rzodkiewkach"}, "rodzajB": "f"}, {"id": "seler-naciowy", "label": "Seler naciowy", "rodzaj": "m", "formy": {"M": "seler naciowy", "D": "selera naciowego", "B": "seler naciowy", "N": "selerem naciowym", "Ms": "selerze naciowym", "Mpl": "selery naciowe", "Dpl": "selerów naciowych", "Bpl": "selery naciowe", "Npl": "selerami naciowymi", "Mspl": "selerach naciowych"}, "rodzajB": "m"}, {"id": "dynia", "label": "Dynia", "rodzaj": "f", "formy": {"M": "dynia", "D": "dyni", "B": "dynię", "N": "dynią", "Ms": "dyni", "Mpl": "dynie", "Dpl": "dyń", "Bpl": "dynie", "Npl": "dyniami", "Mspl": "dyniach"}, "rodzajB": "f"}, {"id": "pieczarki", "label": "Pieczarki", "rodzaj": "pl", "formy": {"M": "pieczarki", "D": "pieczarek", "B": "pieczarki", "N": "pieczarkami", "Ms": "pieczarkach", "Mpl": "pieczarki", "Dpl": "pieczarek", "Bpl": "pieczarki", "Npl": "pieczarkami", "Mspl": "pieczarkach"}, "rodzajB": "pl"}, {"id": "kalafior", "label": "Kalafior", "rodzaj": "m", "formy": {"M": "kalafior", "D": "kalafiora", "B": "kalafior", "N": "kalafiorem", "Ms": "kalafiorze", "Bpot": "kalafiora", "Mpl": "kalafiory", "Dpl": "kalafiorów", "Bpl": "kalafiory", "Npl": "kalafiorami", "Mspl": "kalafiorach"}, "rodzajB": "mz"}, {"id": "baklazan", "label": "Bakłażan", "rodzaj": "m", "formy": {"M": "bakłażan", "D": "bakłażana", "B": "bakłażan", "N": "bakłażanem", "Ms": "bakłażanie", "Bpot": "bakłażana", "Mpl": "bakłażany", "Dpl": "bakłażanów", "Bpl": "bakłażany", "Npl": "bakłażanami", "Mspl": "bakłażanach"}, "rodzajB": "mz"}]}};
window.SWAP_ADJ = {"umyty_B": {"m": "umyty", "f": "umytą", "n": "umyte", "pl": "umyte", "mz": "umytego"}, "swiezy_B": {"m": "świeży", "f": "świeżą", "n": "świeże", "pl": "świeże", "mz": "świeżego"}, "odsaczony_B": {"m": "odsączony", "f": "odsączoną", "n": "odsączone", "pl": "odsączone", "mz": "odsączonego"}, "pieczony_N": {"m": "pieczonym", "f": "pieczoną", "n": "pieczonym", "pl": "pieczonymi", "mz": "pieczonym"}, "pokrojony_B": {"m": "pokrojony", "f": "pokrojoną", "n": "pokrojone", "pl": "pokrojone", "mz": "pokrojonego"}, "ugotowany_B": {"m": "ugotowany", "f": "ugotowaną", "n": "ugotowane", "pl": "ugotowane", "mz": "ugotowanego"}, "podsmazony_B": {"m": "podsmażony", "f": "podsmażoną", "n": "podsmażone", "pl": "podsmażone", "mz": "podsmażonego"}, "przyprawiony_B": {"m": "przyprawiony", "f": "przyprawioną", "n": "przyprawione", "pl": "przyprawione", "mz": "przyprawionego"}, "prazony_N": {"m": "prażonym", "f": "prażoną", "n": "prażonym", "pl": "prażonymi", "mz": "prażonym"}, "pokrojony_N": {"m": "pokrojonym", "f": "pokrojoną", "n": "pokrojonym", "pl": "pokrojonymi", "mz": "pokrojonym"}, "starty_B": {"m": "starty", "f": "startą", "n": "starte", "pl": "starte", "mz": "startego"}, "ugotowany_N": {"m": "ugotowanym", "f": "ugotowaną", "n": "ugotowanym", "pl": "ugotowanymi", "mz": "ugotowanym"}, "przygotowany_B": {"m": "przygotowany", "f": "przygotowaną", "n": "przygotowane", "pl": "przygotowane", "mz": "przygotowanego"}};</script>

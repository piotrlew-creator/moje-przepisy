---
hide:
  - toc
---

<a class="p-back" href="../../">&larr; Wszystkie przepisy</a>

# Bowl z łososiem teriyaki

<div class="p-hero" data-slot="2">
<div class="p-hero__top">
<span>Obiad</span><span class="p-num">13:00-16:00</span>
</div>
<div class="p-macros">
<div class="p-macro"><span class="p-macro__v">596</span><span class="p-macro__l">kcal</span></div>
<div class="p-macro"><span class="p-macro__v">9 g</span><span class="p-macro__l">białko</span></div>
<div class="p-macro"><span class="p-macro__v">63 g</span><span class="p-macro__l">węgl.</span></div>
<div class="p-macro"><span class="p-macro__v">26 g</span><span class="p-macro__l">tłuszcz</span></div>
</div>
<p style="margin:0;font-size:.66rem;color:var(--p-ink-3);font-weight:600">Wartości dla jednej porcji, tak jak w planie diety.</p>
</div>

<div class="p-servings">
<span class="p-eyebrow">Dla ilu osób gotujesz?</span>
<div class="p-stepper">
<button type="button" class="p-stepper__btn" id="srv-minus" aria-label="Mniej osób">&minus;</button>
<span class="p-stepper__value"><span class="p-stepper__num" id="srv-num" aria-live="polite">1</span><span class="p-stepper__word" id="srv-word">osoba</span></span>
<button type="button" class="p-stepper__btn" id="srv-plus" aria-label="Więcej osób">+</button>
</div>
<p class="p-note" id="srv-note" style="margin:0" hidden></p>
</div>

<div class="p-ings__head">
<h2 id="ing-heading" style="margin:0">Składniki na 1 osobę</h2>
<button type="button" class="p-btn p-btn--ghost" id="swap-reset" style="min-height:auto;padding:6px 8px" hidden>Przywróć oryginał</button>
</div>
<ul class="p-ings" id="ing-list">
<li class="p-ings__sec">łosoś</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q"></span><span class="p-ing__n">Łosoś świeży</span><span class="p-ing__g">100 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">1 łyżka</span><span class="p-ing__n">Sos sojowy</span><span class="p-ing__g">10 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">1 łyżka</span><span class="p-ing__n">Sok z limonki</span><span class="p-ing__g">6 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">0.5 plastra</span><span class="p-ing__n">Imbir</span><span class="p-ing__g">2.5 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">0.5 ząbku</span><span class="p-ing__n">Czosnek</span><span class="p-ing__g">3 g</span></div>
</li>
<li class="p-ings__sec">sos</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">0.5 sztuki</span><span class="p-ing__n">Limonka</span><span class="p-ing__g">35 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q"></span><span class="p-ing__n">Syrop z agawy</span><span class="p-ing__g">10 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-6">Zamień na</label>
<select class="p-select" id="swap-6" data-ing="6">
<option value="miod">Miód</option>
<option value="syrop-klonowy">Syrop klonowy</option>
<option value="syrop-z-agawy" selected>Syrop z agawy · oryginał</option>
</select>
</div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">1 plaster</span><span class="p-ing__n">Imbir</span><span class="p-ing__g">5 g</span></div>
</li>
<li class="p-ings__sec">oraz</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q"></span><span class="p-ing__n">Komosa ryżowa</span><span class="p-ing__g">45 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-8">Zamień na</label>
<select class="p-select" id="swap-8" data-ing="8">
<option value="ryz-basmati">Ryż basmati</option>
<option value="ryz-brazowy">Ryż brązowy</option>
<option value="kasza-jaglana">Kasza jaglana</option>
<option value="kasza-gryczana">Kasza gryczana</option>
<option value="kasza-bulgur">Kasza bulgur</option>
<option value="komosa" selected>Komosa ryżowa · oryginał</option>
</select>
</div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q"></span><span class="p-ing__n">Awokado</span><span class="p-ing__g">40 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">0.5 sztuki</span><span class="p-ing__n">Ogórek</span><span class="p-ing__g">75 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-10">Zamień na</label>
<select class="p-select" id="swap-10" data-ing="10">
<option value="pomidor">Pomidor</option>
<option value="ogorek" selected>Ogórek · oryginał</option>
<option value="papryka">Papryka</option>
<option value="cukinia">Cukinia</option>
<option value="brokul">Brokuł</option>
<option value="marchewka">Marchewka</option>
<option value="marchew">Marchew</option>
<option value="rzodkiewka">Rzodkiewka</option>
<option value="seler-naciowy">Seler naciowy</option>
<option value="dynia">Dynia</option>
<option value="pieczarki">Pieczarki</option>
<option value="kalafior">Kalafior</option>
<option value="baklazan">Bakłażan</option>
</select>
</div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q"></span><span class="p-ing__n">Ananas świeży</span><span class="p-ing__g">80 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">0.5 sztuki</span><span class="p-ing__n">Cebula czerwona</span><span class="p-ing__g">40 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">1 plaster</span><span class="p-ing__n">Imbir</span><span class="p-ing__g">5 g</span></div>
</li>
<li data-pantry="1" data-order="name"><div class="p-ing__row"><span class="p-ing__q">2 łyżeczki</span><span class="p-ing__n">Szczypiorek siekany</span><span class="p-ing__g">10 g</span></div>
</li>
<li data-order="name"><div class="p-ing__row"><span class="p-ing__q">1 łyżeczka</span><span class="p-ing__n">Sezam nasiona</span><span class="p-ing__g">5 g</span></div>
</li>
</ul>

<div class="p-actions">
<button type="button" class="p-btn p-btn--block" id="open-shopping">&#128722; Lista zakupów</button>
<button type="button" class="p-btn p-btn--primary p-btn--block" id="cook-start">Gotujmy &rarr;</button>
</div>

<h2>Sposób przygotowania</h2>
<ol class="p-steps" id="steps-list">
<li>Komosę ryżową przygotuj według instrukcji na opakowaniu.</li>
<li>Łososia pokrój na kawałki i polej marynatą: sos sojowy, sok z limonki, starty imbir, czosnek przeciśnięty przez praskę.</li>
<li>Przygotuj sos: dodaj wyciśnięty sok z limonki, odrobinę startej skórki z limonki, syrop z agawy oraz starty imbir.</li>
<li>Komosę przełóż do miski.</li>
<li>Awokado pokrój w paski, ananasa w kostkę, a ogórka w plastry. Cebulę i szczypiorek posiekaj.</li>
<li>W misce z komosą ułóż zamarynowaną rybę, pokrojone warzywa i owoce. Następnie całość polej wcześniej przygotowanym sosem.</li>
<li>Przygotowane danie posyp startym imbirem, szczypiorkiem oraz sezamem.</li>
</ol>

<div class="p-cook" id="cook" data-open="0" role="dialog" aria-modal="true" aria-label="Gotowanie: Bowl z łososiem teriyaki">
<div class="p-cook__bar">
<span class="p-cook__title">Bowl z łososiem teriyaki</span>
<button type="button" class="p-iconbtn" id="cook-close" aria-label="Zamknij tryb gotowania">&times;</button>
</div>
<div class="p-progress" id="cook-progress"></div>
<div class="p-cook__body">
<span class="p-cook__step" id="cook-label"></span>
<p class="p-cook__text" id="cook-text"></p>
</div>
<div class="p-cook__nav">
<button type="button" class="p-btn" id="cook-prev">Wstecz</button>
<button type="button" class="p-btn p-btn--primary" id="cook-next">Następny krok</button>
</div></div>
<div class="p-sheet" id="shopping" data-open="0" role="dialog" aria-modal="true" aria-label="Lista zakupów">
<button type="button" class="p-sheet__scrim" id="shopping-scrim" aria-label="Zamknij listę zakupów"></button>
<div class="p-sheet__panel">
<div class="p-sheet__head"><h2>Lista zakupów</h2><button type="button" class="p-iconbtn" id="close-shopping" aria-label="Zamknij">&times;</button></div>
<div class="p-sheet__body" id="shopping-body"></div>
<div class="p-sheet__foot">
<button type="button" class="p-btn" id="reset-shopping">Odznacz wszystko</button>
<button type="button" class="p-btn p-btn--primary" id="pdf-btn">Wygeneruj PDF</button>
</div></div></div>
<div class="p-toast" id="toast" role="status" data-on="0"></div>

<script>window.RECIPE = {"slug": "bowl-z-lososiem-teriyaki", "title": "Bowl z łososiem teriyaki", "slotLabel": "Obiad", "time": "13:00-16:00", "baseServings": 1, "ingredients": [{"qty": 100.0, "unit": "g", "unitLemma": null, "name": "Łosoś świeży", "grams": 100.0, "pantry": false, "tag": "losos", "nameFirst": true, "weightOnly": true, "section": "łosoś"}, {"qty": 1.0, "unit": "łyżka", "unitLemma": "łyżka", "name": "Sos sojowy", "grams": 10.0, "pantry": false, "tag": "sos-sojowy", "nameFirst": true, "section": "łosoś"}, {"qty": 1.0, "unit": "łyżka", "unitLemma": "łyżka", "name": "Sok z limonki", "grams": 6.0, "pantry": false, "tag": "limonka", "nameFirst": true, "section": "łosoś"}, {"qty": 0.5, "unit": "plastra", "unitLemma": "plaster", "name": "Imbir", "grams": 2.5, "pantry": false, "tag": "imbir", "nameFirst": true, "section": "łosoś"}, {"qty": 0.5, "unit": "ząbku", "unitLemma": "ząbek", "name": "Czosnek", "grams": 3.0, "pantry": false, "tag": "czosnek", "nameFirst": true, "section": "łosoś"}, {"qty": 0.5, "unit": "sztuki", "unitLemma": "sztuka", "name": "Limonka", "grams": 35.0, "pantry": false, "tag": "limonka", "nameFirst": true, "section": "sos"}, {"qty": 10.0, "unit": "g", "unitLemma": null, "name": "Syrop z agawy", "grams": 10.0, "pantry": false, "tag": "syrop-agawa", "nameFirst": true, "weightOnly": true, "section": "sos", "swap": {"group": "slodziki", "self": "syrop-z-agawy", "nameCase": "M"}}, {"qty": 1.0, "unit": "plaster", "unitLemma": "plaster", "name": "Imbir", "grams": 5.0, "pantry": false, "tag": "imbir", "nameFirst": true, "section": "sos"}, {"qty": 45.0, "unit": "g", "unitLemma": null, "name": "Komosa ryżowa", "grams": 45.0, "pantry": false, "tag": "komosa", "nameFirst": true, "weightOnly": true, "section": "oraz", "swap": {"group": "zboza", "self": "komosa", "nameCase": "M"}}, {"qty": 40.0, "unit": "g", "unitLemma": null, "name": "Awokado", "grams": 40.0, "pantry": false, "tag": "awokado", "nameFirst": true, "weightOnly": true, "section": "oraz"}, {"qty": 0.5, "unit": "sztuki", "unitLemma": "sztuka", "name": "Ogórek", "grams": 75.0, "pantry": false, "tag": "ogorek", "nameFirst": true, "section": "oraz", "swap": {"group": "warzywa", "self": "ogorek", "nameCase": "M"}}, {"qty": 80.0, "unit": "g", "unitLemma": null, "name": "Ananas świeży", "grams": 80.0, "pantry": false, "tag": "ananas", "nameFirst": true, "weightOnly": true, "section": "oraz"}, {"qty": 0.5, "unit": "sztuki", "unitLemma": "sztuka", "name": "Cebula czerwona", "grams": 40.0, "pantry": false, "tag": "cebula", "nameFirst": true, "section": "oraz"}, {"qty": 1.0, "unit": "plaster", "unitLemma": "plaster", "name": "Imbir", "grams": 5.0, "pantry": false, "tag": "imbir", "nameFirst": true, "section": "oraz"}, {"qty": 2.0, "unit": "łyżeczki", "unitLemma": "łyżeczka", "name": "Szczypiorek siekany", "grams": 10.0, "pantry": true, "tag": null, "nameFirst": true, "section": "oraz"}, {"qty": 1.0, "unit": "łyżeczka", "unitLemma": "łyżeczka", "name": "Sezam nasiona", "grams": 5.0, "pantry": false, "tag": "sezam", "nameFirst": true, "section": "oraz"}], "steps": ["«8|B|||U» przygotuj według instrukcji na opakowaniu.", "Łososia pokrój na kawałki i polej marynatą: sos sojowy, sok z limonki, starty imbir, czosnek przeciśnięty przez praskę.", "Przygotuj sos: dodaj wyciśnięty sok z limonki, odrobinę startej skórki z limonki, «6|B|||» oraz starty imbir.", "Komosę przełóż do miski.", "Awokado pokrój w paski, ananasa w kostkę, a «10|Bpot|||» w plastry. Cebulę i szczypiorek posiekaj.", "W misce z komosą ułóż zamarynowaną rybę, pokrojone warzywa i owoce. Następnie całość polej wcześniej przygotowanym sosem.", "Przygotowane danie posyp startym imbirem, szczypiorkiem oraz sezamem."]};
window.UNITS = {"łyżka": ["łyżka", "łyżki", "łyżek", "łyżki"], "łyżeczka": ["łyżeczka", "łyżeczki", "łyżeczek", "łyżeczki"], "sztuka": ["sztuka", "sztuki", "sztuk", "sztuki"], "garść": ["garść", "garście", "garści", "garści"], "kromka": ["kromka", "kromki", "kromek", "kromki"], "plaster": ["plaster", "plastry", "plastrów", "plastra"], "szklanka": ["szklanka", "szklanki", "szklanek", "szklanki"], "opakowanie": ["opakowanie", "opakowania", "opakowań", "opakowania"], "ząbek": ["ząbek", "ząbki", "ząbków", "ząbka"], "szczypta": ["szczypta", "szczypty", "szczypt", "szczypty"], "porcja": ["porcja", "porcje", "porcji", "porcji"], "puszka": ["puszka", "puszki", "puszek", "puszki"], "kostka": ["kostka", "kostki", "kostek", "kostki"], "listek": ["listek", "listki", "listków", "listka"], "łodyga": ["łodyga", "łodygi", "łodyg", "łodygi"]};
window.SWAPS = {"slodziki": {"label": "Miód i syropy", "options": [{"id": "miod", "label": "Miód", "rodzaj": "m", "formy": {"M": "miód", "D": "miodu", "B": "miód", "N": "miodem", "Ms": "miodzie"}, "rodzajB": "m"}, {"id": "syrop-klonowy", "label": "Syrop klonowy", "rodzaj": "m", "formy": {"M": "syrop klonowy", "D": "syropu klonowego", "B": "syrop klonowy", "N": "syropem klonowym", "Ms": "syropie klonowym"}, "rodzajB": "m"}, {"id": "syrop-z-agawy", "label": "Syrop z agawy", "rodzaj": "m", "formy": {"M": "syrop z agawy", "D": "syropu z agawy", "B": "syrop z agawy", "N": "syropem z agawy", "Ms": "syropie z agawy"}, "rodzajB": "m"}]}, "warzywa": {"label": "Warzywa", "options": [{"id": "pomidor", "label": "Pomidor", "rodzaj": "m", "formy": {"M": "pomidor", "D": "pomidora", "B": "pomidor", "N": "pomidorem", "Ms": "pomidorze", "Bpot": "pomidora", "Mpl": "pomidory", "Dpl": "pomidorów", "Bpl": "pomidory", "Npl": "pomidorami", "Mspl": "pomidorach"}, "rodzajB": "mz"}, {"id": "ogorek", "label": "Ogórek", "rodzaj": "m", "formy": {"M": "ogórek", "D": "ogórka", "B": "ogórek", "N": "ogórkiem", "Ms": "ogórku", "Bpot": "ogórka", "Mpl": "ogórki", "Dpl": "ogórków", "Bpl": "ogórki", "Npl": "ogórkami", "Mspl": "ogórkach"}, "rodzajB": "mz"}, {"id": "papryka", "label": "Papryka", "rodzaj": "f", "formy": {"M": "papryka", "D": "papryki", "B": "paprykę", "N": "papryką", "Ms": "papryce", "Mpl": "papryki", "Dpl": "papryk", "Bpl": "papryki", "Npl": "paprykami", "Mspl": "paprykach"}, "rodzajB": "f"}, {"id": "cukinia", "label": "Cukinia", "rodzaj": "f", "formy": {"M": "cukinia", "D": "cukinii", "B": "cukinię", "N": "cukinią", "Ms": "cukinii", "Mpl": "cukinie", "Dpl": "cukinii", "Bpl": "cukinie", "Npl": "cukiniami", "Mspl": "cukiniach"}, "rodzajB": "f"}, {"id": "brokul", "label": "Brokuł", "rodzaj": "m", "formy": {"M": "brokuł", "D": "brokuła", "B": "brokuł", "N": "brokułem", "Ms": "brokule", "Bpot": "brokuła", "Mpl": "brokuły", "Dpl": "brokułów", "Bpl": "brokuły", "Npl": "brokułami", "Mspl": "brokułach"}, "rodzajB": "mz"}, {"id": "marchewka", "label": "Marchewka", "rodzaj": "f", "formy": {"M": "marchewka", "D": "marchewki", "B": "marchewkę", "N": "marchewką", "Ms": "marchewce", "Mpl": "marchewki", "Dpl": "marchewek", "Bpl": "marchewki", "Npl": "marchewkami", "Mspl": "marchewkach"}, "rodzajB": "f"}, {"id": "marchew", "label": "Marchew", "rodzaj": "f", "formy": {"M": "marchew", "D": "marchwi", "B": "marchew", "N": "marchwią", "Ms": "marchwi", "Mpl": "marchwie", "Dpl": "marchwi", "Bpl": "marchwie", "Npl": "marchwiami", "Mspl": "marchwiach"}, "rodzajB": "f"}, {"id": "rzodkiewka", "label": "Rzodkiewka", "rodzaj": "f", "formy": {"M": "rzodkiewka", "D": "rzodkiewki", "B": "rzodkiewkę", "N": "rzodkiewką", "Ms": "rzodkiewce", "Mpl": "rzodkiewki", "Dpl": "rzodkiewek", "Bpl": "rzodkiewki", "Npl": "rzodkiewkami", "Mspl": "rzodkiewkach"}, "rodzajB": "f"}, {"id": "seler-naciowy", "label": "Seler naciowy", "rodzaj": "m", "formy": {"M": "seler naciowy", "D": "selera naciowego", "B": "seler naciowy", "N": "selerem naciowym", "Ms": "selerze naciowym", "Mpl": "selery naciowe", "Dpl": "selerów naciowych", "Bpl": "selery naciowe", "Npl": "selerami naciowymi", "Mspl": "selerach naciowych"}, "rodzajB": "m"}, {"id": "dynia", "label": "Dynia", "rodzaj": "f", "formy": {"M": "dynia", "D": "dyni", "B": "dynię", "N": "dynią", "Ms": "dyni", "Mpl": "dynie", "Dpl": "dyń", "Bpl": "dynie", "Npl": "dyniami", "Mspl": "dyniach"}, "rodzajB": "f"}, {"id": "pieczarki", "label": "Pieczarki", "rodzaj": "pl", "formy": {"M": "pieczarki", "D": "pieczarek", "B": "pieczarki", "N": "pieczarkami", "Ms": "pieczarkach", "Mpl": "pieczarki", "Dpl": "pieczarek", "Bpl": "pieczarki", "Npl": "pieczarkami", "Mspl": "pieczarkach"}, "rodzajB": "pl"}, {"id": "kalafior", "label": "Kalafior", "rodzaj": "m", "formy": {"M": "kalafior", "D": "kalafiora", "B": "kalafior", "N": "kalafiorem", "Ms": "kalafiorze", "Bpot": "kalafiora", "Mpl": "kalafiory", "Dpl": "kalafiorów", "Bpl": "kalafiory", "Npl": "kalafiorami", "Mspl": "kalafiorach"}, "rodzajB": "mz"}, {"id": "baklazan", "label": "Bakłażan", "rodzaj": "m", "formy": {"M": "bakłażan", "D": "bakłażana", "B": "bakłażan", "N": "bakłażanem", "Ms": "bakłażanie", "Bpot": "bakłażana", "Mpl": "bakłażany", "Dpl": "bakłażanów", "Bpl": "bakłażany", "Npl": "bakłażanami", "Mspl": "bakłażanach"}, "rodzajB": "mz"}]}, "zboza": {"label": "Ryż i kasze", "options": [{"id": "ryz-basmati", "label": "Ryż basmati", "rodzaj": "m", "formy": {"M": "ryż basmati", "D": "ryżu basmati", "B": "ryż basmati", "N": "ryżem basmati", "Ms": "ryżu basmati"}, "rodzajB": "m"}, {"id": "ryz-brazowy", "label": "Ryż brązowy", "rodzaj": "m", "formy": {"M": "ryż brązowy", "D": "ryżu brązowego", "B": "ryż brązowy", "N": "ryżem brązowym", "Ms": "ryżu brązowym"}, "rodzajB": "m"}, {"id": "kasza-jaglana", "label": "Kasza jaglana", "rodzaj": "f", "formy": {"M": "kasza jaglana", "D": "kaszy jaglanej", "B": "kaszę jaglaną", "N": "kaszą jaglaną", "Ms": "kaszy jaglanej"}, "rodzajB": "f"}, {"id": "kasza-gryczana", "label": "Kasza gryczana", "rodzaj": "f", "formy": {"M": "kasza gryczana", "D": "kaszy gryczanej", "B": "kaszę gryczaną", "N": "kaszą gryczaną", "Ms": "kaszy gryczanej"}, "rodzajB": "f"}, {"id": "kasza-bulgur", "label": "Kasza bulgur", "rodzaj": "f", "formy": {"M": "kasza bulgur", "D": "kaszy bulgur", "B": "kaszę bulgur", "N": "kaszą bulgur", "Ms": "kaszy bulgur"}, "rodzajB": "f"}, {"id": "komosa", "label": "Komosa ryżowa", "rodzaj": "f", "formy": {"M": "komosa ryżowa", "D": "komosy ryżowej", "B": "komosę ryżową", "N": "komosą ryżową", "Ms": "komosie ryżowej"}, "rodzajB": "f"}]}};
window.SWAP_ADJ = {"umyty_B": {"m": "umyty", "f": "umytą", "n": "umyte", "pl": "umyte", "mz": "umytego"}, "swiezy_B": {"m": "świeży", "f": "świeżą", "n": "świeże", "pl": "świeże", "mz": "świeżego"}, "odsaczony_B": {"m": "odsączony", "f": "odsączoną", "n": "odsączone", "pl": "odsączone", "mz": "odsączonego"}, "pieczony_N": {"m": "pieczonym", "f": "pieczoną", "n": "pieczonym", "pl": "pieczonymi", "mz": "pieczonym"}, "pokrojony_B": {"m": "pokrojony", "f": "pokrojoną", "n": "pokrojone", "pl": "pokrojone", "mz": "pokrojonego"}, "ugotowany_B": {"m": "ugotowany", "f": "ugotowaną", "n": "ugotowane", "pl": "ugotowane", "mz": "ugotowanego"}, "podsmazony_B": {"m": "podsmażony", "f": "podsmażoną", "n": "podsmażone", "pl": "podsmażone", "mz": "podsmażonego"}, "przyprawiony_B": {"m": "przyprawiony", "f": "przyprawioną", "n": "przyprawione", "pl": "przyprawione", "mz": "przyprawionego"}, "prazony_N": {"m": "prażonym", "f": "prażoną", "n": "prażonym", "pl": "prażonymi", "mz": "prażonym"}, "pokrojony_N": {"m": "pokrojonym", "f": "pokrojoną", "n": "pokrojonym", "pl": "pokrojonymi", "mz": "pokrojonym"}, "starty_B": {"m": "starty", "f": "startą", "n": "starte", "pl": "starte", "mz": "startego"}, "ugotowany_N": {"m": "ugotowanym", "f": "ugotowaną", "n": "ugotowanym", "pl": "ugotowanymi", "mz": "ugotowanym"}, "przygotowany_B": {"m": "przygotowany", "f": "przygotowaną", "n": "przygotowane", "pl": "przygotowane", "mz": "przygotowanego"}};</script>

---
hide:
  - toc
---

<a class="p-back" href="../../">&larr; Wszystkie przepisy</a>

# Tost z awokado i mozzarellą

<div class="p-hero" data-slot="1">
<div class="p-hero__top">
<span>Śniadanie</span><span class="p-num">7:00-10:00</span>
</div>
<div class="p-macros">
<div class="p-macro"><span class="p-macro__v">463</span><span class="p-macro__l">kcal</span></div>
<div class="p-macro"><span class="p-macro__v">23 g</span><span class="p-macro__l">białko</span></div>
<div class="p-macro"><span class="p-macro__v">39 g</span><span class="p-macro__l">węgl.</span></div>
<div class="p-macro"><span class="p-macro__v">22 g</span><span class="p-macro__l">tłuszcz</span></div>
</div>
<p style="margin:0;font-size:.66rem;color:var(--p-ink-3);font-weight:600">Wartości dla jednej porcji, tak jak w planie diety.</p>
</div>

<div class="p-servings">
<span class="p-eyebrow">Dla ilu osób gotujesz?</span>
<div class="p-stepper">
<button type="button" class="p-stepper__btn" id="srv-minus" aria-label="Mniej osób">&minus;</button>
<span class="p-stepper__value"><span class="p-stepper__num" id="srv-num" aria-live="polite">1</span><span class="p-stepper__word" id="srv-word">osoba</span></span>
<button type="button" class="p-stepper__btn" id="srv-plus" aria-label="Więcej osób">+</button>
</div>
<p class="p-note" id="srv-note" style="margin:0" hidden></p>
</div>

<div class="p-ings__head">
<h2 id="ing-heading" style="margin:0">Składniki na 1 osobę</h2>
<button type="button" class="p-btn p-btn--ghost" id="swap-reset" style="min-height:auto;padding:6px 8px" hidden>Przywróć oryginał</button>
</div>
<ul class="p-ings" id="ing-list">
<li><div class="p-ing__row"><span class="p-ing__q">2 kromki</span><span class="p-ing__n">chleba żytniego razowego</span><span class="p-ing__g">60 g</span></div>
<div class="p-ing__swap">
<label class="p-swaplabel" for="swap-0">Zamień na</label>
<select class="p-select" id="swap-0" data-ing="0">
<option value="chleb-zytni-razowy" selected>Chleb żytni razowy · oryginał</option>
<option value="chleb-zytni">Chleb żytni</option>
<option value="chleb-orkiszowy">Chleb orkiszowy</option>
<option value="chleb-pelnoziarnisty">Chleb pełnoziarnisty</option>
<option value="chleb-na-zakwasie">Chleb żytni na zakwasie</option>
<option value="bulka-grahamka">Bułka grahamka</option>
<option value="bulka-owsiana">Bułka owsiana</option>
</select>
</div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">6 plastrów</span><span class="p-ing__n">mozzarelli</span><span class="p-ing__g">90 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">0.25 sztuki</span><span class="p-ing__n">awokado</span><span class="p-ing__g">35 g</span></div>
</li>
<li><div class="p-ing__row"><span class="p-ing__q">1 sztuka</span><span class="p-ing__n">małego pomidora</span><span class="p-ing__g">80 g</span></div>
</li>
</ul>

<div class="p-actions">
<button type="button" class="p-btn p-btn--block" id="open-shopping">&#128722; Lista zakupów</button>
<button type="button" class="p-btn p-btn--primary p-btn--block" id="cook-start">Gotujmy &rarr;</button>
</div>

<h2>Sposób przygotowania</h2>
<ol class="p-steps" id="steps-list">
<li>Mozzarellę pokrój w plastry.</li>
<li>Na kromce chleba ułóż mozzarellę, pokrojone awokado i plastry pomidora. Przykryj pozostałą mozzarellą i drugą kromką.</li>
<li>Tosty podpiecz na patelni bez tłuszczu przez 3 minuty pod przykryciem, następnie obróć na kolejne 3 minuty. Smacznego!</li>
</ol>

<div class="p-cook" id="cook" data-open="0" role="dialog" aria-modal="true" aria-label="Gotowanie: Tost z awokado i mozzarellą">
<div class="p-cook__bar">
<span class="p-cook__title">Tost z awokado i mozzarellą</span>
<button type="button" class="p-iconbtn" id="cook-close" aria-label="Zamknij tryb gotowania">&times;</button>
</div>
<div class="p-progress" id="cook-progress"></div>
<div class="p-cook__body">
<span class="p-cook__step" id="cook-label"></span>
<p class="p-cook__text" id="cook-text"></p>
</div>
<div class="p-cook__nav">
<button type="button" class="p-btn" id="cook-prev">Wstecz</button>
<button type="button" class="p-btn p-btn--primary" id="cook-next">Następny krok</button>
</div></div>
<div class="p-sheet" id="shopping" data-open="0" role="dialog" aria-modal="true" aria-label="Lista zakupów">
<button type="button" class="p-sheet__scrim" id="shopping-scrim" aria-label="Zamknij listę zakupów"></button>
<div class="p-sheet__panel">
<div class="p-sheet__head"><h2>Lista zakupów</h2><button type="button" class="p-iconbtn" id="close-shopping" aria-label="Zamknij">&times;</button></div>
<div class="p-sheet__body" id="shopping-body"></div>
<div class="p-sheet__foot">
<button type="button" class="p-btn" id="reset-shopping">Odznacz wszystko</button>
<button type="button" class="p-btn p-btn--primary" id="pdf-btn">Wygeneruj PDF</button>
</div></div></div>
<div class="p-toast" id="toast" role="status" data-on="0"></div>

<script>window.RECIPE = {"slug": "tost-z-awokado-i-mozzarella", "title": "Tost z awokado i mozzarellą", "slotLabel": "Śniadanie", "time": "7:00-10:00", "baseServings": 1, "ingredients": [{"qty": 2.0, "unit": "kromki", "unitLemma": "kromka", "name": "chleba żytniego razowego", "grams": 60.0, "pantry": false, "tag": "chleb", "swap": {"group": "pieczywo", "self": "chleb-zytni-razowy", "nameCase": "D"}}, {"qty": 6.0, "unit": "plastrów", "unitLemma": "plaster", "name": "mozzarelli", "grams": 90.0, "pantry": false, "tag": "mozzarella"}, {"qty": 0.25, "unit": "sztuki", "unitLemma": "sztuka", "name": "awokado", "grams": 35.0, "pantry": false, "tag": "awokado"}, {"qty": 1.0, "unit": "sztuka", "unitLemma": "sztuka", "name": "małego pomidora", "grams": 80.0, "pantry": false, "tag": "pomidor"}], "steps": ["Mozzarellę pokrój w plastry.", "Na kromce chleba ułóż mozzarellę, pokrojone awokado i plastry pomidora. Przykryj pozostałą mozzarellą i drugą kromką.", "Tosty podpiecz na patelni bez tłuszczu przez 3 minuty pod przykryciem, następnie obróć na kolejne 3 minuty. Smacznego!"]};
window.UNITS = {"łyżka": ["łyżka", "łyżki", "łyżek", "łyżki"], "łyżeczka": ["łyżeczka", "łyżeczki", "łyżeczek", "łyżeczki"], "sztuka": ["sztuka", "sztuki", "sztuk", "sztuki"], "garść": ["garść", "garście", "garści", "garści"], "kromka": ["kromka", "kromki", "kromek", "kromki"], "plaster": ["plaster", "plastry", "plastrów", "plastra"], "szklanka": ["szklanka", "szklanki", "szklanek", "szklanki"], "opakowanie": ["opakowanie", "opakowania", "opakowań", "opakowania"], "ząbek": ["ząbek", "ząbki", "ząbków", "ząbka"], "szczypta": ["szczypta", "szczypty", "szczypt", "szczypty"], "porcja": ["porcja", "porcje", "porcji", "porcji"], "puszka": ["puszka", "puszki", "puszek", "puszki"], "kostka": ["kostka", "kostki", "kostek", "kostki"], "listek": ["listek", "listki", "listków", "listka"], "łodyga": ["łodyga", "łodygi", "łodyg", "łodygi"]};
window.SWAPS = {"pieczywo": {"label": "Pieczywo", "options": [{"id": "chleb-zytni-razowy", "label": "Chleb żytni razowy", "rodzaj": "m", "formy": {"M": "chleb żytni razowy", "D": "chleba żytniego razowego", "B": "chleb żytni razowy", "N": "chlebem żytnim razowym", "Ms": "chlebie żytnim razowym"}, "rodzajB": "m"}, {"id": "chleb-zytni", "label": "Chleb żytni", "rodzaj": "m", "formy": {"M": "chleb żytni", "D": "chleba żytniego", "B": "chleb żytni", "N": "chlebem żytnim", "Ms": "chlebie żytnim"}, "rodzajB": "m"}, {"id": "chleb-orkiszowy", "label": "Chleb orkiszowy", "rodzaj": "m", "formy": {"M": "chleb orkiszowy", "D": "chleba orkiszowego", "B": "chleb orkiszowy", "N": "chlebem orkiszowym", "Ms": "chlebie orkiszowym"}, "rodzajB": "m"}, {"id": "chleb-pelnoziarnisty", "label": "Chleb pełnoziarnisty", "rodzaj": "m", "formy": {"M": "chleb pełnoziarnisty", "D": "chleba pełnoziarnistego", "B": "chleb pełnoziarnisty", "N": "chlebem pełnoziarnistym", "Ms": "chlebie pełnoziarnistym"}, "rodzajB": "m"}, {"id": "chleb-na-zakwasie", "label": "Chleb żytni na zakwasie", "rodzaj": "m", "formy": {"M": "chleb żytni na zakwasie", "D": "chleba żytniego na zakwasie", "B": "chleb żytni na zakwasie", "N": "chlebem żytnim na zakwasie", "Ms": "chlebie żytnim na zakwasie"}, "rodzajB": "m"}, {"id": "bulka-grahamka", "label": "Bułka grahamka", "rodzaj": "f", "formy": {"M": "bułka grahamka", "D": "bułki grahamki", "B": "bułkę grahamkę", "N": "bułką grahamką", "Ms": "bułce grahamce"}, "rodzajB": "f"}, {"id": "bulka-owsiana", "label": "Bułka owsiana", "rodzaj": "f", "formy": {"M": "bułka owsiana", "D": "bułki owsianej", "B": "bułkę owsianą", "N": "bułką owsianą", "Ms": "bułce owsianej"}, "rodzajB": "f"}]}};
window.SWAP_ADJ = {"umyty_B": {"m": "umyty", "f": "umytą", "n": "umyte", "pl": "umyte", "mz": "umytego"}, "swiezy_B": {"m": "świeży", "f": "świeżą", "n": "świeże", "pl": "świeże", "mz": "świeżego"}, "odsaczony_B": {"m": "odsączony", "f": "odsączoną", "n": "odsączone", "pl": "odsączone", "mz": "odsączonego"}, "pieczony_N": {"m": "pieczonym", "f": "pieczoną", "n": "pieczonym", "pl": "pieczonymi", "mz": "pieczonym"}, "pokrojony_B": {"m": "pokrojony", "f": "pokrojoną", "n": "pokrojone", "pl": "pokrojone", "mz": "pokrojonego"}, "ugotowany_B": {"m": "ugotowany", "f": "ugotowaną", "n": "ugotowane", "pl": "ugotowane", "mz": "ugotowanego"}, "podsmazony_B": {"m": "podsmażony", "f": "podsmażoną", "n": "podsmażone", "pl": "podsmażone", "mz": "podsmażonego"}, "przyprawiony_B": {"m": "przyprawiony", "f": "przyprawioną", "n": "przyprawione", "pl": "przyprawione", "mz": "przyprawionego"}, "prazony_N": {"m": "prażonym", "f": "prażoną", "n": "prażonym", "pl": "prażonymi", "mz": "prażonym"}, "pokrojony_N": {"m": "pokrojonym", "f": "pokrojoną", "n": "pokrojonym", "pl": "pokrojonymi", "mz": "pokrojonym"}, "starty_B": {"m": "starty", "f": "startą", "n": "starte", "pl": "starte", "mz": "startego"}, "ugotowany_N": {"m": "ugotowanym", "f": "ugotowaną", "n": "ugotowanym", "pl": "ugotowanymi", "mz": "ugotowanym"}, "przygotowany_B": {"m": "przygotowany", "f": "przygotowaną", "n": "przygotowane", "pl": "przygotowane", "mz": "przygotowanego"}};</script>
